var class_jarroncode =
[
    [ "corazon", "class_jarroncode.html#a4403b35e16ac4a8ae0015bb9efee3399", null ],
    [ "corazonestotal", "class_jarroncode.html#a0eefa355c8d4d141a1a185eb9b29b987", null ],
    [ "delay", "class_jarroncode.html#a53e7bea2d1c723d0a3acc1dfcff1384e", null ]
];