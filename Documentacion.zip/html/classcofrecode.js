var classcofrecode =
[
    [ "coins", "classcofrecode.html#a9cdc9cc0c144005cff2536efac42f032", null ],
    [ "coinstotal", "classcofrecode.html#aa0f0adfdac9c380261a249d082769c89", null ],
    [ "delay", "classcofrecode.html#ae25162a4a7db4128f85581f789ad44f9", null ]
];