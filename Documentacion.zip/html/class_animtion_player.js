var class_animtion_player =
[
    [ "actualizarPuntajeEnemigoFinal", "class_animtion_player.html#ac4de5f1711795c372137985f7ab0f0a4", null ],
    [ "cofres_obtenidos", "class_animtion_player.html#a478140ea0705f8ffc037b4c15f1871b8", null ],
    [ "healthBar", "class_animtion_player.html#af70b9d894f2b90ced32bfccd47fdb534", null ],
    [ "personaje_zona_segura", "class_animtion_player.html#a54605af65094c5d3497a3f62efa2a455", null ],
    [ "posx", "class_animtion_player.html#a6cbdfdb378ffc4251372d4e43dcc3638", null ],
    [ "posy", "class_animtion_player.html#a3b52a83486c40fe50ed0920ba0104b54", null ],
    [ "Text", "class_animtion_player.html#a7bb0d6f36365f4a97d8e0f07cdd5fa74", null ],
    [ "trans", "class_animtion_player.html#a7fc67c2f7f6fcd43a303987d60d56551", null ],
    [ "ultimoestado", "class_animtion_player.html#a49a848f9cee25d698c7bcd9a1e9c4ed6", null ],
    [ "Velocidad", "class_animtion_player.html#aa6cf168b4355599e913d96cbd20ee441", null ],
    [ "vivo", "class_animtion_player.html#ae626e9d594df625db5f4eb3492477083", null ],
    [ "x", "class_animtion_player.html#acf2455761c9dfe2ae793ae115a13d1e0", null ]
];