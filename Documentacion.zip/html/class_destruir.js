var class_destruir =
[
    [ "prueba", "class_destruir.html#aff3a735cc5a1a938a83e72368ee0a040", null ],
    [ "objectdestruir", "class_destruir.html#aaa6d4b638ff9376c8548e1207c768095", null ]
];