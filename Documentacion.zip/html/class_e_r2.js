var class_e_r2 =
[
    [ "inRadio", "class_e_r2.html#afdc3ebff322b32d427b19e490a2ecd24", null ],
    [ "movimiento", "class_e_r2.html#ab55da84e14336aea2954e12dd5a5bc93", null ],
    [ "first", "class_e_r2.html#a8a45110fe04d86df9b61cb34632f9037", null ],
    [ "newposx", "class_e_r2.html#a652b9bc356182db2b38ca7dbfa5f716b", null ],
    [ "newposy", "class_e_r2.html#a3c0df02d9883d5355c8fbdea2238456e", null ],
    [ "posx", "class_e_r2.html#a3c143636c7dd63c56bab4f69bca4d6e9", null ],
    [ "posX", "class_e_r2.html#ad56ea8527be3fe1e3c4e483a9d89191e", null ],
    [ "posy", "class_e_r2.html#afa85b7b37e1c23a301d6d20310d8e84f", null ],
    [ "posY", "class_e_r2.html#a67677d344124ddb0a9a876bbd2210dce", null ],
    [ "prefab2", "class_e_r2.html#ae929ed2ccc8ebb65a8e24ec6e382d4d5", null ],
    [ "radiovision", "class_e_r2.html#a93c9d7df6f99eedd9e11ed7a267a8d7c", null ],
    [ "tamañoradio", "class_e_r2.html#ae914841f84f4088e179aaa4a28172694", null ],
    [ "ultimoestado", "class_e_r2.html#af7eb37597ff984e3fed2ad4d5a250d96", null ],
    [ "Velocidad", "class_e_r2.html#a6b1f826050f996367e5a9d14d1d2be54", null ],
    [ "vivo", "class_e_r2.html#a5faa81bcf152e7ccafdac8d1dc95cc0e", null ]
];