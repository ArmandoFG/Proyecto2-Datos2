var class_e_a2 =
[
    [ "inRadio", "class_e_a2.html#a557eab4632225750df976f5e5cdfa6e7", null ],
    [ "movimiento", "class_e_a2.html#a59f035572dcfaeb14475200bcc7f02c5", null ],
    [ "newposx", "class_e_a2.html#a6fa39ba8f286d9dad91cdaffb89be59b", null ],
    [ "newposy", "class_e_a2.html#a2af0734fb83f06d40545d8986f672e3a", null ],
    [ "posx", "class_e_a2.html#ae8186c19dcea03fa4a71069ff74d78f0", null ],
    [ "posX", "class_e_a2.html#afc1d9f3921bd5ec322fdf7cf12d36a85", null ],
    [ "posy", "class_e_a2.html#ad34f67bc07c67347c99bdc44ddccb9fe", null ],
    [ "posY", "class_e_a2.html#a880bfac2e87b6931901f7bf0add8a15f", null ],
    [ "radiovision", "class_e_a2.html#a563ad25c6dfea76a70f3747728f49eeb", null ],
    [ "tamañoradio", "class_e_a2.html#a976692af7e49ce0be316fd0331131df3", null ],
    [ "ultimoestado", "class_e_a2.html#a7c34e5c8167ae2ae78b51db02c77a315", null ],
    [ "Velocidad", "class_e_a2.html#a25c062c533b82f74724ca2e1e5a3aead", null ],
    [ "vivo", "class_e_a2.html#a0c4c6248265ab6e782a75e87b3ed5f40", null ]
];