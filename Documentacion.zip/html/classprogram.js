var classprogram =
[
    [ "b", "classprogram.html#aba8291cc106efca2ab0864518dae7484", null ],
    [ "info", "classprogram.html#a95a8d67a5f7fafa53462b282bd7aa6f8", null ],
    [ "ipAddress", "classprogram.html#a30f66e580445f433c622237dc6892d60", null ],
    [ "ipHostInfo", "classprogram.html#a8f39d72ad3d078152c9bb7d3e44251c6", null ],
    [ "len", "classprogram.html#ae81f8a3c531db47294739d52ba7132a1", null ],
    [ "lenR", "classprogram.html#a50160c5a51bca02bae708402ee5716d7", null ],
    [ "rb", "classprogram.html#ae441394ad46c2853da2f96255d8c1a5b", null ],
    [ "remoteEP", "classprogram.html#aa3a25282b53a2443e6fcc1dde8b81113", null ],
    [ "sender", "classprogram.html#a656580211189b816dbd837e511e3d2a1", null ]
];