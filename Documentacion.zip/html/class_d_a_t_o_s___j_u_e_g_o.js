var class_d_a_t_o_s___j_u_e_g_o =
[
    [ "cofres", "class_d_a_t_o_s___j_u_e_g_o.html#a241efa31723c1a61f2d40a86584103b4", null ],
    [ "curHealth", "class_d_a_t_o_s___j_u_e_g_o.html#aba2529b0527b2f07721448e4c720002b", null ],
    [ "level", "class_d_a_t_o_s___j_u_e_g_o.html#aeafcf5dae839984b9589e8d5f5ffd7d3", null ],
    [ "maxHealth", "class_d_a_t_o_s___j_u_e_g_o.html#a1045d14ee80faec9dfdd9523501aca6d", null ],
    [ "puntos", "class_d_a_t_o_s___j_u_e_g_o.html#a8ce3ea3243955f126f87a46103a87898", null ],
    [ "vidas", "class_d_a_t_o_s___j_u_e_g_o.html#a752d2d448b4031929a77c4169e894cf0", null ]
];