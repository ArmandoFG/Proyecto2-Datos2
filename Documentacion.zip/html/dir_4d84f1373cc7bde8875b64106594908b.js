var dir_4d84f1373cc7bde8875b64106594908b =
[
    [ "Ojoespectral.cs", "_ojoespectral_8cs.html", [
      [ "Ojoespectral", "class_ojoespectral.html", "class_ojoespectral" ]
    ] ],
    [ "Ojoespectral2.cs", "_ojoespectral2_8cs.html", [
      [ "Ojoespectral2", "class_ojoespectral2.html", "class_ojoespectral2" ]
    ] ],
    [ "Ojoespectral3.cs", "_ojoespectral3_8cs.html", [
      [ "Ojoespectral3", "class_ojoespectral3.html", "class_ojoespectral3" ]
    ] ]
];