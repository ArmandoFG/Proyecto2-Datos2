var class_e_a1 =
[
    [ "inRadio", "class_e_a1.html#a54ea97af1054e26ed8fcdc75d90eb5f7", null ],
    [ "movimiento", "class_e_a1.html#a344237162ac705021deea27f2bcd372e", null ],
    [ "newposx", "class_e_a1.html#a53f76a45f47e6c99f247de3e91987a76", null ],
    [ "newposy", "class_e_a1.html#a9da0f5efa355b941c2de6dc5805ec2ac", null ],
    [ "posx", "class_e_a1.html#a714e7d81d8aef0e394081f51a290efaf", null ],
    [ "posX", "class_e_a1.html#a290643413634832936d7b9ed8c143314", null ],
    [ "posy", "class_e_a1.html#a9803ccc9e2dd6f2b5f715e577a678da7", null ],
    [ "posY", "class_e_a1.html#af0b296e1b774215cd7cec3fbb689e3de", null ],
    [ "radiovision", "class_e_a1.html#a35d238c3e225f49ce26e371099ab9d5f", null ],
    [ "tamañoradio", "class_e_a1.html#afe1e4480d70af044bada6376179ebca2", null ],
    [ "ultimoestado", "class_e_a1.html#a92adcf599255a34eb02c3d480e3fc1da", null ],
    [ "Velocidad", "class_e_a1.html#a5f789baccea0fcba053ea797e57b54e1", null ],
    [ "vivo", "class_e_a1.html#a7586fac2819e32871f89373b531ce33b", null ]
];