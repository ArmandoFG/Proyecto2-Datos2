var class_personaje =
[
    [ "ToString", "class_personaje.html#a38dd1508abd9690464498a90bce6e5f0", null ],
    [ "name", "class_personaje.html#a58079e513390d7289fcedf5246021e4b", null ],
    [ "posx", "class_personaje.html#ae9044a8e6c2b465f55469367b3bae491", null ],
    [ "posy", "class_personaje.html#aed16b199dc8a55dba4c9b24bc29a544e", null ],
    [ "radiovision", "class_personaje.html#afb236fc18637f731de7c62cdb551f747", null ],
    [ "tamanoradio", "class_personaje.html#ada0da0f7546189f24cde1b3bc6583352", null ],
    [ "velocidad", "class_personaje.html#a0c838be54202fc096364f216b011daea", null ],
    [ "vivo", "class_personaje.html#a26ee6fe81caee629c00bc86632d57cf9", null ]
];