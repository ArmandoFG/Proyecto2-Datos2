var class_espectro__rojo__code =
[
    [ "inRadio", "class_espectro__rojo__code.html#a191683ea8c344b882407a871f0531541", null ],
    [ "movimiento", "class_espectro__rojo__code.html#a317732b451825dd51e2a4628a9fe365d", null ],
    [ "first", "class_espectro__rojo__code.html#ac121c3f79662ba61a46fc0a176dddbad", null ],
    [ "newposx", "class_espectro__rojo__code.html#a1eccf0a0b3b268e7d696b68b39fa76ca", null ],
    [ "newposy", "class_espectro__rojo__code.html#ac237cfcb1dab98e3330083d9e3714cff", null ],
    [ "posx", "class_espectro__rojo__code.html#aeea1ffead177e649a1ccfd15b8149303", null ],
    [ "posX", "class_espectro__rojo__code.html#ada581aed5be7cdcd612d0de71cba1e55", null ],
    [ "posy", "class_espectro__rojo__code.html#a7f9a2801b9986cb9a3e3051e531f0a13", null ],
    [ "posY", "class_espectro__rojo__code.html#a4f0a379979aa998583cee58847e64ddd", null ],
    [ "prefab", "class_espectro__rojo__code.html#a5ff0bcf0ddd67ab67c517ac03b2ac135", null ],
    [ "radiovision", "class_espectro__rojo__code.html#aa462f3afc456616bea9daf91818e7da7", null ],
    [ "tamañoradio", "class_espectro__rojo__code.html#af8702b4e58850f6386e5e2568af3d26e", null ],
    [ "ultimoestado", "class_espectro__rojo__code.html#ac978480d233ac5d5a881d31917661a36", null ],
    [ "Velocidad", "class_espectro__rojo__code.html#af960dae12c4e59bf1adf93240efa084b", null ],
    [ "vivo", "class_espectro__rojo__code.html#a18b87bf49f7c0a92adacf4f89e15c8c1", null ]
];