var class_e_g__04 =
[
    [ "inRadio", "class_e_g__04.html#a5ea295d4ab109e2a800e4c6122ae8200", null ],
    [ "movimiento", "class_e_g__04.html#ab7272bb9d05a151b4816b8504da4cd43", null ],
    [ "newposx", "class_e_g__04.html#a7e122d1440d7a118cd06235169bd8fe3", null ],
    [ "newposy", "class_e_g__04.html#adb26baea2bb44030f208772c86359211", null ],
    [ "posx", "class_e_g__04.html#a534a2cf79da4ce274b38841c101ad304", null ],
    [ "posX", "class_e_g__04.html#a354a156f7bbb8f583d2562037970d8e0", null ],
    [ "posy", "class_e_g__04.html#abcc1d1a0d95c9bf9540e4a96a6612e29", null ],
    [ "posY", "class_e_g__04.html#a2c3a2002a5953d027d043e48b0754b07", null ],
    [ "radiovision", "class_e_g__04.html#a562720a231f37f9cdaac5afbcab0b965", null ],
    [ "tamañoradio", "class_e_g__04.html#ad5f29a24b48bd16a2e579a47ca9829d8", null ],
    [ "ultimoestado", "class_e_g__04.html#a30b7e99b0a052701ea9f6088c8d6866d", null ],
    [ "Velocidad", "class_e_g__04.html#af88597e2719b678bff8a8347959926e0", null ],
    [ "vivo", "class_e_g__04.html#a4e9d01fac605f60e420ea0f428f78c7a", null ]
];