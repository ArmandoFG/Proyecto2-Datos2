var classrata1 =
[
    [ "inRadio", "classrata1.html#a5c181ffd313eb13b466f301b743c0d6d", null ],
    [ "movimiento", "classrata1.html#a601ccf5c42879af65059c5b6040cb557", null ],
    [ "newposx", "classrata1.html#a0f36a5f872f1ac66142b07f53ded067f", null ],
    [ "newposy", "classrata1.html#ad5b861a851950cc0ffb4bf2e7ac83389", null ],
    [ "posx", "classrata1.html#ac44330f56cb36afa75f367373f474990", null ],
    [ "posX", "classrata1.html#a5dc28eb3ada14b3dee86d24b6566aae8", null ],
    [ "posy", "classrata1.html#a4cbdbd40b5182b57569fcd6b65b9cd9e", null ],
    [ "posY", "classrata1.html#ad71115a284ba2c3a43ddaf7287aab933", null ],
    [ "radiovision", "classrata1.html#a9b69eaccdf0f8af8bf063087af61cc87", null ],
    [ "tamañoradio", "classrata1.html#ae57f2a0873103d73e56aa33d64fabd22", null ],
    [ "ultimoestado", "classrata1.html#a39f1fc8f3b3df04f135ffc8aa6cb71a9", null ],
    [ "Velocidad", "classrata1.html#ae6b625cea6541dd0ae5515bf24d76df5", null ],
    [ "vivo", "classrata1.html#a22ab0cdf2de9a714decb62a8c01462dd", null ]
];