var class_ojoespectral =
[
    [ "posx", "class_ojoespectral.html#af5c541ddb4f7dd4ffaa8f1f529937ea2", null ],
    [ "posy", "class_ojoespectral.html#a55be45b1ced0fb6d290bc2bf47cdc68b", null ],
    [ "radiovision", "class_ojoespectral.html#a649e655540ca69e747351e856bf68ca9", null ],
    [ "RadioVision", "class_ojoespectral.html#ab14029e7a0296eee76db0dfbad40aa50", null ],
    [ "sonidoChocobo", "class_ojoespectral.html#a2f6815d80739582e1c5e5c647ce1f84a", null ],
    [ "tamañoradio", "class_ojoespectral.html#af7fe7bd1f16f2ecab9225bc823d5dba8", null ],
    [ "velocidad", "class_ojoespectral.html#a439a07583f4a13f840b355fd4dc842cf", null ],
    [ "Velocidad", "class_ojoespectral.html#af845f21e093baa7f0b7fd58f82e18f7f", null ],
    [ "vivo", "class_ojoespectral.html#ac7273c14668dc3077b94ac1738105ae7", null ]
];