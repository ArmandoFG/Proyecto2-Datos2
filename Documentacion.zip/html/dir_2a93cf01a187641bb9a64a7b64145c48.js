var dir_2a93cf01a187641bb9a64a7b64145c48 =
[
    [ "cambio1.cs", "cambio1_8cs.html", [
      [ "cambio1", "classcambio1.html", null ]
    ] ],
    [ "cambio2.cs", "cambio2_8cs.html", [
      [ "cambio2", "classcambio2.html", null ]
    ] ],
    [ "cambio3.cs", "cambio3_8cs.html", [
      [ "cambio3", "classcambio3.html", null ]
    ] ],
    [ "cambio4.cs", "cambio4_8cs.html", [
      [ "cambio4", "classcambio4.html", null ]
    ] ],
    [ "cambio5.cs", "cambio5_8cs.html", [
      [ "cambio5", "classcambio5.html", null ]
    ] ]
];