var class_ojoespectral3 =
[
    [ "posx", "class_ojoespectral3.html#a67ba9f1a06df5eaead4a5acce6e75e7d", null ],
    [ "posy", "class_ojoespectral3.html#ac06baed72877d3feedbb0aaaf934842b", null ],
    [ "radiovision", "class_ojoespectral3.html#a444dc199a4022b96a96952081a1be6e0", null ],
    [ "RadioVision", "class_ojoespectral3.html#aca6f5e108c0c7bc7da018df6357853ca", null ],
    [ "sonidoChocobo", "class_ojoespectral3.html#a6199d9adb962dad23af0bca3c7a3066e", null ],
    [ "tamañoradio", "class_ojoespectral3.html#a6dd53af322a8fcb24e7af04cdb213a6a", null ],
    [ "velocidad", "class_ojoespectral3.html#a3d3c19bd65dbd14f2cd3d14a61a8f9dd", null ],
    [ "Velocidad", "class_ojoespectral3.html#a9c8e385a80c51d59cf23abe8bf508143", null ],
    [ "vivo", "class_ojoespectral3.html#a67fa43bc6947358cd0be8fb4c6b615bb", null ]
];