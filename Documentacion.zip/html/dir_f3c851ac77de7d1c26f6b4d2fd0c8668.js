var dir_f3c851ac77de7d1c26f6b4d2fd0c8668 =
[
    [ "pruebacliente.cs", "pruebacliente_8cs.html", [
      [ "pruebacliente", "classpruebacliente.html", null ]
    ] ],
    [ "TCPTestClient.cs", "_t_c_p_test_client_8cs.html", [
      [ "TCPTestClient", "class_t_c_p_test_client.html", "class_t_c_p_test_client" ]
    ] ]
];