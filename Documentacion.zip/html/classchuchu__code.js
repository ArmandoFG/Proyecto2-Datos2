var classchuchu__code =
[
    [ "Attack", "classchuchu__code.html#a11b53bd794ef85dd6e63ea1962cf88e6", null ],
    [ "flecha", "classchuchu__code.html#a9ad741639ca9b006cc2b41184ada1e69", null ],
    [ "LineaVision", "classchuchu__code.html#af53644bc228193845aaafa6d08b07af1", null ],
    [ "numArrows", "classchuchu__code.html#ad9800b9edce3dcde410ace6770c6165f", null ],
    [ "posChuchu", "classchuchu__code.html#a87e3c24bf75b5ede4cc26af216980fef", null ],
    [ "posx", "classchuchu__code.html#ab84cac5aa963dc05e948423be57f5e53", null ],
    [ "posy", "classchuchu__code.html#a725f9c8c4fabd20dfe7c81f631c36083", null ],
    [ "prefab", "classchuchu__code.html#a12dbb110806fff5ed89731bcfe25864b", null ],
    [ "radiovision", "classchuchu__code.html#a6b627f09ac1d64ee8e7a3ec2ff949583", null ],
    [ "tamañoradio", "classchuchu__code.html#ae07348474a321e3439e60c07deb05fa0", null ],
    [ "target", "classchuchu__code.html#a336e435d117878fe18d465b716dd5097", null ],
    [ "velocidad", "classchuchu__code.html#a32f97526e338c0751e2ac1be0d211d82", null ],
    [ "Velocidad", "classchuchu__code.html#afefd184bbaae1383b475fe8e44b10342", null ],
    [ "vivo", "classchuchu__code.html#a804e77ae94659c793b39ecea5a51d27a", null ]
];