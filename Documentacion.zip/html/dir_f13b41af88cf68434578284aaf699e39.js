var dir_f13b41af88cf68434578284aaf699e39 =
[
    [ "BolasDeFuego", "dir_2101190ad844ed6b79c145a3946294db.html", "dir_2101190ad844ed6b79c145a3946294db" ],
    [ "Cambio de nivel", "dir_2a93cf01a187641bb9a64a7b64145c48.html", "dir_2a93cf01a187641bb9a64a7b64145c48" ],
    [ "chuchu", "dir_e17be227fbaf7e8dc8bbe0bfe0461f01.html", "dir_e17be227fbaf7e8dc8bbe0bfe0461f01" ],
    [ "Clientes P", "dir_f3c851ac77de7d1c26f6b4d2fd0c8668.html", "dir_f3c851ac77de7d1c26f6b4d2fd0c8668" ],
    [ "Enemigo Final", "dir_d8be178d5f9b4518c7adbb89c3f442f7.html", "dir_d8be178d5f9b4518c7adbb89c3f442f7" ],
    [ "Espectro Azul", "dir_a714cbb252743bbbe3060885679d17d9.html", "dir_a714cbb252743bbbe3060885679d17d9" ],
    [ "Espectro Rojo", "dir_d35d2527950ea42609638788b16497ba.html", "dir_d35d2527950ea42609638788b16497ba" ],
    [ "EspectrosGris", "dir_b6dd701207e08b45ac989d36eb7c9f03.html", "dir_b6dd701207e08b45ac989d36eb7c9f03" ],
    [ "Objetos", "dir_dd20c10adfa6acd1f2d716151368104f.html", "dir_dd20c10adfa6acd1f2d716151368104f" ],
    [ "Ojoespectral", "dir_4d84f1373cc7bde8875b64106594908b.html", "dir_4d84f1373cc7bde8875b64106594908b" ],
    [ "Rata", "dir_3fdcf46a6034f3c247c0311e5ade4cb2.html", "dir_3fdcf46a6034f3c247c0311e5ade4cb2" ],
    [ "camaracontr.cs", "camaracontr_8cs.html", [
      [ "camaracontr", "classcamaracontr.html", "classcamaracontr" ]
    ] ],
    [ "DATOS_JUEGO.cs", "_d_a_t_o_s___j_u_e_g_o_8cs.html", [
      [ "DATOS_JUEGO", "class_d_a_t_o_s___j_u_e_g_o.html", "class_d_a_t_o_s___j_u_e_g_o" ]
    ] ],
    [ "program.cs", "program_8cs.html", [
      [ "program", "classprogram.html", "classprogram" ]
    ] ],
    [ "PruebaDATOS.cs", "_prueba_d_a_t_o_s_8cs.html", [
      [ "PruebaDATOS", "class_prueba_d_a_t_o_s.html", "class_prueba_d_a_t_o_s" ],
      [ "Personaje", "class_personaje.html", "class_personaje" ],
      [ "ListaPersonajes", "class_lista_personajes.html", "class_lista_personajes" ],
      [ "Juego", "class_juego.html", "class_juego" ]
    ] ],
    [ "TCPTestServer.cs", "_t_c_p_test_server_8cs.html", [
      [ "TCPTestServer", "class_t_c_p_test_server.html", "class_t_c_p_test_server" ]
    ] ],
    [ "TimeLive.cs", "_time_live_8cs.html", [
      [ "TimeLive", "class_time_live.html", "class_time_live" ]
    ] ]
];