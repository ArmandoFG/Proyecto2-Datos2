var class_doxygen_window =
[
    [ "WindowModes", "class_doxygen_window.html#ad1f6043062e30f52cb634b72294a5676", [
      [ "Generate", "class_doxygen_window.html#ad1f6043062e30f52cb634b72294a5676a32b919d18cfaca89383f6000dcc9c031", null ],
      [ "Configuration", "class_doxygen_window.html#ad1f6043062e30f52cb634b72294a5676a254f642527b45bc260048e30704edb39", null ],
      [ "About", "class_doxygen_window.html#ad1f6043062e30f52cb634b72294a5676a8f7f4c1ce7a4f933663d10543562b096", null ]
    ] ],
    [ "Init", "class_doxygen_window.html#a48f456c44b07cc9283a0583579b1d65a", null ],
    [ "MakeNewDoxyFile", "class_doxygen_window.html#abf3c2a3c3a53e6691e58b865da8404de", null ],
    [ "OnDoxygenFinished", "class_doxygen_window.html#a2809a93b756a6cfc371ee76a9d7168d7", null ],
    [ "readBaseConfig", "class_doxygen_window.html#a5ba38d9b1d93fa627bc3b53cdd1dda17", null ],
    [ "RunDoxygen", "class_doxygen_window.html#a63924417d5b5b7a71570ec9a9ef1ca5e", null ],
    [ "AssestsFolder", "class_doxygen_window.html#a470870b3c6a44b3fe2f57870e39cfe55", null ],
    [ "BaseFileString", "class_doxygen_window.html#a7a4acfac0a07a2a05f183e4f0bc53b62", null ],
    [ "CurentOutput", "class_doxygen_window.html#a82b41ae2e3c44b050acc7603031ccd55", null ],
    [ "DoxygenOutputString", "class_doxygen_window.html#a20e7d1bdb1f32c97f600bf0f0bdb2358", null ],
    [ "Instance", "class_doxygen_window.html#a45d09c9a64d2873367470303789e3bf9", null ],
    [ "SelectedTheme", "class_doxygen_window.html#aff9bfc8c7ed3f017a61e67025ea7c99a", null ],
    [ "Themes", "class_doxygen_window.html#a2dfb0ba26737a0e996797c2848cc2fc0", null ],
    [ "UnityProjectID", "class_doxygen_window.html#a0c52f34973444c41e90151536dbd6e82", null ]
];