var class_enemigo_final =
[
    [ "inRadio", "class_enemigo_final.html#ad8e7c0526773fc537bd8d7ea253c0feb", null ],
    [ "inRadio2", "class_enemigo_final.html#aef044cdc698a262716506c63c907bcec", null ],
    [ "movimiento", "class_enemigo_final.html#a59c3247ab28bff569e302d6d5ba2c3f1", null ],
    [ "curHealth", "class_enemigo_final.html#aab599d00e3cd4180c1ca2fc0f2348016", null ],
    [ "first", "class_enemigo_final.html#ac78feee166d1db13f400235185b62051", null ],
    [ "healthBar", "class_enemigo_final.html#a3ca0a737cc86c8ed0a09482e2c4e621a", null ],
    [ "newposx", "class_enemigo_final.html#ac27f549222fbc10fcc07c515ebc6091f", null ],
    [ "newposy", "class_enemigo_final.html#a52147984ce974dc3185ee639d46b1131", null ],
    [ "posx", "class_enemigo_final.html#a2e70d28b8f89eb30bfcae1204656d80e", null ],
    [ "posX", "class_enemigo_final.html#a58a22d04ee196d874470a953fe1164b2", null ],
    [ "posy", "class_enemigo_final.html#aca7d370daa608391f5faf08f68a10e63", null ],
    [ "posY", "class_enemigo_final.html#aa8c3690c640ec8dc89d0a92ef57f6948", null ],
    [ "prefab", "class_enemigo_final.html#a293e9cfbb6d494a394127460f1acca03", null ],
    [ "radiovision", "class_enemigo_final.html#a20e79a95710ea5a869796466723d6890", null ],
    [ "tamañoradio", "class_enemigo_final.html#ab0472bfaf6710d9244db77d3a1bf1d40", null ],
    [ "ultimoestado", "class_enemigo_final.html#aa6b998ddfcda2b4a7c04aec0aff74f69", null ],
    [ "Velocidad", "class_enemigo_final.html#ad4e8eb7f009b371ee71b0e718d29c617", null ],
    [ "vivo", "class_enemigo_final.html#ae36f7d5b9a7315721649b45b22f30d9e", null ]
];