var class_prueba_d_a_t_o_s =
[
    [ "enviardatos", "class_prueba_d_a_t_o_s.html#a626aee70cf5a3d2410f578a729e673e6", null ],
    [ "Recibirdatos", "class_prueba_d_a_t_o_s.html#a36761301b3a4c4f3f8ba8793464906ab", null ]
];