var class_lista_personajes =
[
    [ "Listar", "class_lista_personajes.html#ab0a588680b79fa65a41e4b8d092f4834", null ],
    [ "personajes", "class_lista_personajes.html#a64b031562ee5cf3e184888a02164d289", null ]
];