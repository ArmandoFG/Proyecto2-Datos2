var class_e_a0 =
[
    [ "inRadio", "class_e_a0.html#ae3a252a6b11f3eb18188d8fa350c19e8", null ],
    [ "movimiento", "class_e_a0.html#a90d48b591bd4af5d9a2fee72d60eb7ad", null ],
    [ "newposx", "class_e_a0.html#a00d185aa7fcf040eddafa72883f878cd", null ],
    [ "newposy", "class_e_a0.html#a4907d852195f235ac34b59e6a1046165", null ],
    [ "posx", "class_e_a0.html#a2210a3a40cdb6c582725f76cf05614c9", null ],
    [ "posX", "class_e_a0.html#a1bddb8f92440fc77fc769cb68725a568", null ],
    [ "posy", "class_e_a0.html#abe4850d45dc0988ab89d4916ce5272b4", null ],
    [ "posY", "class_e_a0.html#a3447846cffc881c4eb2d454adba44baa", null ],
    [ "radiovision", "class_e_a0.html#afc0ee8419cb236df2fa5564a0182b1b7", null ],
    [ "tamañoradio", "class_e_a0.html#a65f92d763572ce76e98870f77da3d68d", null ],
    [ "ultimoestado", "class_e_a0.html#a555deaa590e88868291176db772b891a", null ],
    [ "Velocidad", "class_e_a0.html#a58a002b51362835c005b3095fb39a660", null ],
    [ "vivo", "class_e_a0.html#aa3cce68f6272fd44f427a7f75eb14abe", null ]
];