var classcreditos =
[
    [ "text1", "classcreditos.html#a76d1eb02a313931e775c73c5b0766503", null ],
    [ "text2", "classcreditos.html#af66d32cad357a8d703cbc5e31b4cf8ed", null ]
];