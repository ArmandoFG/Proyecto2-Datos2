var class_t_c_p_test_client =
[
    [ "ipAddress", "class_t_c_p_test_client.html#a95e95e43e58a99d55858cb730a03f37e", null ],
    [ "ipHostInfo", "class_t_c_p_test_client.html#a8fe08ca147ac420c94a4fe0366ce7f16", null ],
    [ "path", "class_t_c_p_test_client.html#ac06d1d55a47d70ac61f849ab90f859ed", null ],
    [ "remoteEP", "class_t_c_p_test_client.html#ad446543ff2e76f8bfb650eeb85af4dd7", null ],
    [ "sender", "class_t_c_p_test_client.html#a4affc7e11088585e7bca24fd621a176a", null ]
];