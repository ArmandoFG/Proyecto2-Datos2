var dir_bd165367a18a39208395791a5dd37d40 =
[
    [ "ER1.cs", "_e_r1_8cs.html", [
      [ "ER1", "class_e_r1.html", "class_e_r1" ]
    ] ],
    [ "ER2.cs", "_e_r2_8cs.html", [
      [ "ER2", "class_e_r2.html", "class_e_r2" ]
    ] ],
    [ "Espectro_rojo_code.cs", "_espectro__rojo__code_8cs.html", [
      [ "Espectro_rojo_code", "class_espectro__rojo__code.html", "class_espectro__rojo__code" ]
    ] ]
];