var searchData=
[
  ['tostring_314',['ToString',['../class_personaje.html#a38dd1508abd9690464498a90bce6e5f0',1,'Personaje.ToString()'],['../class_juego.html#a8c924a5572c538e29a77906adb2cc440',1,'Juego.ToString()']]]
];
