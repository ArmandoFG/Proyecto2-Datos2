var searchData=
[
  ['tamanoradio_168',['tamanoradio',['../class_personaje.html#ada0da0f7546189f24cde1b3bc6583352',1,'Personaje']]],
  ['tamañoradio_169',['tamañoradio',['../classchuchu__code.html#ae07348474a321e3439e60c07deb05fa0',1,'chuchu_code.tamañoradio()'],['../class_enemigo_final.html#ab0472bfaf6710d9244db77d3a1bf1d40',1,'EnemigoFinal.tamañoradio()'],['../class_e_a0.html#a65f92d763572ce76e98870f77da3d68d',1,'EA0.tamañoradio()'],['../class_e_a1.html#afe1e4480d70af044bada6376179ebca2',1,'EA1.tamañoradio()'],['../class_e_a2.html#a976692af7e49ce0be316fd0331131df3',1,'EA2.tamañoradio()'],['../class_e_r1.html#a91444a0a1a853e2c9d2159b49e74ba89',1,'ER1.tamañoradio()'],['../class_e_r2.html#ae914841f84f4088e179aaa4a28172694',1,'ER2.tamañoradio()'],['../class_espectro__rojo__code.html#af8702b4e58850f6386e5e2568af3d26e',1,'Espectro_rojo_code.tamañoradio()'],['../class_e_g2.html#a14e183847ad281ba527294d8f2fde341',1,'EG2.tamañoradio()'],['../class_e_g3.html#a0e0767b7ff3bf32134c8918b4817e3ce',1,'EG3.tamañoradio()'],['../class_espectro_gris1.html#aa102428c76ece75ff7a9a62676a2359e',1,'EspectroGris1.tamañoradio()'],['../class_e_g__04.html#ad5f29a24b48bd16a2e579a47ca9829d8',1,'EG_04.tamañoradio()'],['../class_ojoespectral.html#af7fe7bd1f16f2ecab9225bc823d5dba8',1,'Ojoespectral.tamañoradio()'],['../class_ojoespectral2.html#a14f4b113ca638a4ea44fd9338adf00fc',1,'Ojoespectral2.tamañoradio()'],['../class_ojoespectral3.html#a6dd53af322a8fcb24e7af04cdb213a6a',1,'Ojoespectral3.tamañoradio()'],['../classrata0.html#a6a2ac1144a3c7429a1a9a6fb0700b57a',1,'rata0.tamañoradio()'],['../classrata1.html#ae57f2a0873103d73e56aa33d64fabd22',1,'rata1.tamañoradio()']]],
  ['target_170',['target',['../classchuchu__code.html#a336e435d117878fe18d465b716dd5097',1,'chuchu_code']]],
  ['tcptestclient_171',['TCPTestClient',['../class_t_c_p_test_client.html',1,'']]],
  ['tcptestclient_2ecs_172',['TCPTestClient.cs',['../_t_c_p_test_client_8cs.html',1,'']]],
  ['tcptestserver_173',['TCPTestServer',['../class_t_c_p_test_server.html',1,'']]],
  ['tcptestserver_2ecs_174',['TCPTestServer.cs',['../_t_c_p_test_server_8cs.html',1,'']]],
  ['text_175',['Text',['../class_animtion_player.html#a7bb0d6f36365f4a97d8e0f07cdd5fa74',1,'AnimtionPlayer']]],
  ['text1_176',['text1',['../classcreditos.html#a76d1eb02a313931e775c73c5b0766503',1,'creditos']]],
  ['text2_177',['text2',['../classcreditos.html#af66d32cad357a8d703cbc5e31b4cf8ed',1,'creditos']]],
  ['themes_178',['Themes',['../class_doxygen_window.html#a2dfb0ba26737a0e996797c2848cc2fc0',1,'DoxygenWindow']]],
  ['timelive_179',['TimeLive',['../class_time_live.html',1,'TimeLive'],['../class_time_live.html#a1cf02e48d96f2d5e2b77e028f682b651',1,'TimeLive.timeLive()']]],
  ['timelive_2ecs_180',['TimeLive.cs',['../_time_live_8cs.html',1,'']]],
  ['tostring_181',['ToString',['../class_personaje.html#a38dd1508abd9690464498a90bce6e5f0',1,'Personaje.ToString()'],['../class_juego.html#a8c924a5572c538e29a77906adb2cc440',1,'Juego.ToString()']]],
  ['trans_182',['trans',['../class_animtion_player.html#a7fc67c2f7f6fcd43a303987d60d56551',1,'AnimtionPlayer']]]
];
