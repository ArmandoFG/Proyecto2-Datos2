var searchData=
[
  ['maxhealth_346',['maxHealth',['../class_d_a_t_o_s___j_u_e_g_o.html#a1045d14ee80faec9dfdd9523501aca6d',1,'DATOS_JUEGO']]]
];
