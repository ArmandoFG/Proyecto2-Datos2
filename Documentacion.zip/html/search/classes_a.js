var searchData=
[
  ['rata0_239',['rata0',['../classrata0.html',1,'']]],
  ['rata1_240',['rata1',['../classrata1.html',1,'']]]
];
