var searchData=
[
  ['cofres_322',['cofres',['../class_d_a_t_o_s___j_u_e_g_o.html#a241efa31723c1a61f2d40a86584103b4',1,'DATOS_JUEGO.cofres()'],['../class_juego.html#ac9d63cca9ffe9f269ca0871dc54fba51',1,'Juego.cofres()']]],
  ['cofres_5fobtenidos_323',['cofres_obtenidos',['../class_animtion_player.html#a478140ea0705f8ffc037b4c15f1871b8',1,'AnimtionPlayer']]],
  ['coins_324',['coins',['../classcofrecode.html#a9cdc9cc0c144005cff2536efac42f032',1,'cofrecode']]],
  ['coinstotal_325',['coinstotal',['../classcofrecode.html#aa0f0adfdac9c380261a249d082769c89',1,'cofrecode']]],
  ['corazon_326',['corazon',['../class_jarroncode.html#a4403b35e16ac4a8ae0015bb9efee3399',1,'Jarroncode']]],
  ['corazonestotal_327',['corazonestotal',['../class_jarroncode.html#a0eefa355c8d4d141a1a185eb9b29b987',1,'Jarroncode']]],
  ['curentoutput_328',['CurentOutput',['../class_doxygen_window.html#a82b41ae2e3c44b050acc7603031ccd55',1,'DoxygenWindow']]],
  ['curhealth_329',['curHealth',['../class_d_a_t_o_s___j_u_e_g_o.html#aba2529b0527b2f07721448e4c720002b',1,'DATOS_JUEGO.curHealth()'],['../class_enemigo_final.html#aab599d00e3cd4180c1ca2fc0f2348016',1,'EnemigoFinal.curHealth()']]]
];
