var searchData=
[
  ['actualizarpuntajeenemigofinal_288',['actualizarPuntajeEnemigoFinal',['../class_animtion_player.html#ac4de5f1711795c372137985f7ab0f0a4',1,'AnimtionPlayer']]],
  ['attack_289',['Attack',['../classchuchu__code.html#a11b53bd794ef85dd6e63ea1962cf88e6',1,'chuchu_code']]]
];
