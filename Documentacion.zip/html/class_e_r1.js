var class_e_r1 =
[
    [ "inRadio", "class_e_r1.html#a77d7fe0c0c331f3a8a8ccff1ed66f754", null ],
    [ "movimiento", "class_e_r1.html#a68fb930234f71fe715fd806bda032e4a", null ],
    [ "first", "class_e_r1.html#a52e7e0a3c2dcac69ae116831fc6f024d", null ],
    [ "newposx", "class_e_r1.html#ae6a194e34ecb3d25031924d605fd9f3b", null ],
    [ "newposy", "class_e_r1.html#aa5915fa6871dea31a07c83ccc26820c1", null ],
    [ "posx", "class_e_r1.html#a222c68e5d4af256e91d65f2e9d569e39", null ],
    [ "posX", "class_e_r1.html#a55374d65ed047309023b632fbb670e0b", null ],
    [ "posy", "class_e_r1.html#ad8b56550544d15d9a9d39335e9e69ea2", null ],
    [ "posY", "class_e_r1.html#afbe58277ded0d653fb396d4e96b122fd", null ],
    [ "prefab2", "class_e_r1.html#a4bdec63cb2e3b1c52041d7cff0a5a8c7", null ],
    [ "radiovision", "class_e_r1.html#ae9773335d66885803ca90e171a6f0e4f", null ],
    [ "tamañoradio", "class_e_r1.html#a91444a0a1a853e2c9d2159b49e74ba89", null ],
    [ "ultimoestado", "class_e_r1.html#a5a10d4857fe7cd2757de6e5e5fe01eb5", null ],
    [ "Velocidad", "class_e_r1.html#a7f9b51324a289dc06a029f490d8fe495", null ],
    [ "vivo", "class_e_r1.html#aaacc5bc36ab885cda2b33ee68b34ca82", null ]
];