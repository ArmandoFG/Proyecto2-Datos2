var class_juego =
[
    [ "ToString", "class_juego.html#a8c924a5572c538e29a77906adb2cc440", null ],
    [ "cofres", "class_juego.html#ac9d63cca9ffe9f269ca0871dc54fba51", null ],
    [ "level", "class_juego.html#a237c79aad9cc7b095ce8d34ccecaa432", null ],
    [ "personaje_zona_segura", "class_juego.html#a1c683af45812e1579b9d941c78fb592f", null ],
    [ "puntos", "class_juego.html#a1be38453f786db3b7002687cf3f16086", null ],
    [ "vidas", "class_juego.html#af4e8cfd58dc9cb1f23f0b6b9f258dee0", null ]
];