var classrata0 =
[
    [ "inRadio", "classrata0.html#adfacb33634bd6a649a97f62492980aae", null ],
    [ "movimiento", "classrata0.html#adaca82400e9dacf2195aa03d2a00e36d", null ],
    [ "newposx", "classrata0.html#a867943475402aed5a257c8d138ec511b", null ],
    [ "newposy", "classrata0.html#ac4748cb4ca064529d1aaa8c218b2d08b", null ],
    [ "posx", "classrata0.html#ae16915afdaf09c8eecb627a53cbfa4b6", null ],
    [ "posX", "classrata0.html#a401f5ccff8419ed6aa144f00ae1bca3e", null ],
    [ "posy", "classrata0.html#a6c7679966234dc4883a1e69d84c18fb4", null ],
    [ "posY", "classrata0.html#a735ee2c6da87f3942a6a535940cffb55", null ],
    [ "radiovision", "classrata0.html#a06686091e16c7ba923153757905771c9", null ],
    [ "tamañoradio", "classrata0.html#a6a2ac1144a3c7429a1a9a6fb0700b57a", null ],
    [ "ultimoestado", "classrata0.html#acccdef9156ca169e92de3ea624538233", null ],
    [ "Velocidad", "classrata0.html#aee8d22461c88e612337be538a82a87d4", null ],
    [ "vivo", "classrata0.html#a3f3b93a5635d3fcf6e3711cf6a7206b2", null ]
];