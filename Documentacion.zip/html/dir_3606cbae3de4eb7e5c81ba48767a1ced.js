var dir_3606cbae3de4eb7e5c81ba48767a1ced =
[
    [ "EG2.cs", "_e_g2_8cs.html", [
      [ "EG2", "class_e_g2.html", "class_e_g2" ]
    ] ],
    [ "EG3.cs", "_e_g3_8cs.html", [
      [ "EG3", "class_e_g3.html", "class_e_g3" ]
    ] ],
    [ "EspectroGris1.cs", "_espectro_gris1_8cs.html", [
      [ "EspectroGris1", "class_espectro_gris1.html", "class_espectro_gris1" ]
    ] ]
];