var class_espectro_gris1 =
[
    [ "inRadio", "class_espectro_gris1.html#a10e991f44b0afedde3cd13144f8de32a", null ],
    [ "movimiento", "class_espectro_gris1.html#adcd241853de0901c1335f78baaeef3e4", null ],
    [ "newposx", "class_espectro_gris1.html#a9c631dae5e49b19dee493d0d44f5ef3a", null ],
    [ "newposy", "class_espectro_gris1.html#ab7630c3dd500308b4785277d081e1536", null ],
    [ "posx", "class_espectro_gris1.html#abbe42fbb6ccb2709cf5f71240c982c3e", null ],
    [ "posX", "class_espectro_gris1.html#a5873ed3a5d9b79d35e4ea3c7cbb7fa18", null ],
    [ "posy", "class_espectro_gris1.html#aae60e4c370578405bf0be3df944745fc", null ],
    [ "posY", "class_espectro_gris1.html#a2a7a1c6be22e7f9cfa18f58268f39d61", null ],
    [ "radiovision", "class_espectro_gris1.html#acfa04cfac45bab38e8056c68c80c6f71", null ],
    [ "tamañoradio", "class_espectro_gris1.html#aa102428c76ece75ff7a9a62676a2359e", null ],
    [ "ultimoestado", "class_espectro_gris1.html#a9519f74d61e0f3d1c87a7f9ed3e14815", null ],
    [ "Velocidad", "class_espectro_gris1.html#a56bee5f2450a8066779c2df4b5f7c0ec", null ],
    [ "vivo", "class_espectro_gris1.html#a6a1083f940ee855ba8657f96b68c5b29", null ]
];