var class_e_g3 =
[
    [ "inRadio", "class_e_g3.html#a6916c379894c868dde8c92f4b07f1309", null ],
    [ "movimiento", "class_e_g3.html#aa895a0f82786e55acedc7b2ec37478ed", null ],
    [ "newposx", "class_e_g3.html#a9c35f87fde9375da7e0c38fc18de2bf2", null ],
    [ "newposy", "class_e_g3.html#aca30de4a6448f69e8aadef512ed8f241", null ],
    [ "posx", "class_e_g3.html#af5ac5dd0c67f1d361a016b0ab7cabe41", null ],
    [ "posX", "class_e_g3.html#af0d0d1d102cf5f87e1a704b7f10d58b8", null ],
    [ "posy", "class_e_g3.html#a98a83e67b1e1dd7ca9e143e5a559228e", null ],
    [ "posY", "class_e_g3.html#a84a6afb499a053997e768203a08c51f9", null ],
    [ "radiovision", "class_e_g3.html#a98f173d1304720e2bee97efd7e52a489", null ],
    [ "tamañoradio", "class_e_g3.html#a0e0767b7ff3bf32134c8918b4817e3ce", null ],
    [ "ultimoestado", "class_e_g3.html#a3944339f4d852cc7c924af5f594ba4d2", null ],
    [ "Velocidad", "class_e_g3.html#a2f13938a54d3c618229f642d24f946ab", null ],
    [ "vivo", "class_e_g3.html#a697d7b3e2ff0e516ae393735e07cc986", null ]
];