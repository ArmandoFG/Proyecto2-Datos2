var classcamaracontr =
[
    [ "personaje", "classcamaracontr.html#a333981a516fd8e9714063be29f9a5182", null ]
];