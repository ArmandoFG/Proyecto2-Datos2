var class_ojoespectral2 =
[
    [ "posx", "class_ojoespectral2.html#a299d85bb2a58c5bb810c6e20c73cd4b1", null ],
    [ "posy", "class_ojoespectral2.html#a74bb58cbd0f7e8b38ee78b055f7b7341", null ],
    [ "radiovision", "class_ojoespectral2.html#af9a3ad52b05243a002709e86ef8374eb", null ],
    [ "RadioVision", "class_ojoespectral2.html#a877b840e8a8241f476647705d822d2fc", null ],
    [ "sonidoChocobo", "class_ojoespectral2.html#afbe943627bd976b0aaee3bbcef2e4797", null ],
    [ "tamañoradio", "class_ojoespectral2.html#a14f4b113ca638a4ea44fd9338adf00fc", null ],
    [ "velocidad", "class_ojoespectral2.html#aa8ef6f2f8283a03eeab9eccd3f21f715", null ],
    [ "Velocidad", "class_ojoespectral2.html#a40479b98340fec5ab0645eafd52f15ea", null ],
    [ "vivo", "class_ojoespectral2.html#aab174667ada58f19fcece56c75502d2c", null ]
];