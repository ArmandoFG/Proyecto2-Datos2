var dir_84bbf7b3c7f28a5a18725745e1505219 =
[
    [ "Editor", "dir_a61728ed8d39ae932c553f4837da35dd.html", "dir_a61728ed8d39ae932c553f4837da35dd" ],
    [ "PlayerCode", "dir_3d3340e91468c2bddb2025e7f8fecc7e.html", "dir_3d3340e91468c2bddb2025e7f8fecc7e" ],
    [ "Scripts", "dir_f13b41af88cf68434578284aaf699e39.html", "dir_f13b41af88cf68434578284aaf699e39" ],
    [ "CambioPrincipal.cs", "_cambio_principal_8cs.html", [
      [ "CambioPrincipal", "class_cambio_principal.html", "class_cambio_principal" ]
    ] ],
    [ "creditos.cs", "creditos_8cs.html", [
      [ "creditos", "classcreditos.html", "classcreditos" ]
    ] ],
    [ "Destruir.cs", "_destruir_8cs.html", [
      [ "Destruir", "class_destruir.html", "class_destruir" ]
    ] ],
    [ "llllll.cs", "llllll_8cs.html", [
      [ "llllll", "classllllll.html", null ]
    ] ],
    [ "prueba.cs", "prueba_8cs.html", [
      [ "prueba", "classprueba.html", null ]
    ] ]
];