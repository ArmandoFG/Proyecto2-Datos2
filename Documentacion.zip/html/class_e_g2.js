var class_e_g2 =
[
    [ "inRadio", "class_e_g2.html#a8ba09bdd59399c3be439d152e07918a5", null ],
    [ "movimiento", "class_e_g2.html#a57b929c468e0706314001b06e9e46c8a", null ],
    [ "newposx", "class_e_g2.html#aa98ab30ed2da8110a477dbddc1e0aca2", null ],
    [ "newposy", "class_e_g2.html#a94875bccfc2f6dd690a866c3f980cfe1", null ],
    [ "posx", "class_e_g2.html#a8472a0a81c54c89c48a174bded89eeda", null ],
    [ "posX", "class_e_g2.html#a7a1c50b6e553dc0e35411b5eebc62600", null ],
    [ "posy", "class_e_g2.html#accc00ccb5fd611ba2c9e06d4c7594e83", null ],
    [ "posY", "class_e_g2.html#ad991733bc8e6cf2d1967dd6cbde324d0", null ],
    [ "radiovision", "class_e_g2.html#afd91fc7ad6a42c667c44014a91237db8", null ],
    [ "tamañoradio", "class_e_g2.html#a14e183847ad281ba527294d8f2fde341", null ],
    [ "ultimoestado", "class_e_g2.html#a89ca8ffbaaccb000b8f49393e0239f2b", null ],
    [ "Velocidad", "class_e_g2.html#af832f969f0f1b7c13310baa54b57680f", null ],
    [ "vivo", "class_e_g2.html#a5084b53dca4ba8efc7dc039aee22db38", null ]
];