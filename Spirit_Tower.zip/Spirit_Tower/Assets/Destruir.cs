﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Destruir : MonoBehaviour
{
    public GameObject objectdestruir;
    // Start is called before the first frame update
    private void Awake()
    {

        DontDestroyOnLoad(objectdestruir);
    }
    public void prueba() {
        Debug.Log("sifunka");
        SceneManager.LoadScene("Level 1");
        DATOS_JUEGO.level = "Level 1";
    }
}

