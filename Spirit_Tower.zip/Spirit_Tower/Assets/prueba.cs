﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class prueba : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        Vector3 target = new Vector3(1.9f, 0.0f, 0.0f);
        transform.position = Vector3.MoveTowards(transform.position ,target, 2 * Time.deltaTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
