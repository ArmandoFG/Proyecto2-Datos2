﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;

public class Ojoespectral : MonoBehaviour
{
    public static float posx;
    public static float posy;
    public static bool vivo;
    public static bool radiovision;
    public static double tamañoradio;
    public double RadioVision;
    public float velocidad;
    public static double Velocidad;
    bool first = true;
    Vector3 PosicionInicial;
    GameObject player;

    public GameObject sonidoChocobo;
    // Start is called before the first frame update
    void Start()
    {
        posx = gameObject.transform.position.x;
        posy = gameObject.transform.position.y;
        vivo = true;
        player = GameObject.FindGameObjectWithTag("Player");
        PosicionInicial = transform.position;

    }

    // Update is called once per frame
    void Update()
    {
        velocidad = (float)Velocidad;
        radiovision = false;
        RadioVision = tamañoradio;
        Vector3 target = PosicionInicial;
        float dist = Vector3.Distance(player.transform.position, transform.position);
        if (dist < RadioVision)
        {
            radiovision = true;
            target = player.transform.position;
            float arregloVelocidad = velocidad * Time.deltaTime;
            transform.position = Vector3.MoveTowards(transform.position, target, arregloVelocidad);
            Debug.DrawLine(transform.position, target, Color.green);
            if (first == true)
            {
                Instantiate(sonidoChocobo);
                Destroy(GameObject.Find("clone"));
                first = false;
            }
        }
        else {
            first = true;
            radiovision = false;
        }

    }

    
}
