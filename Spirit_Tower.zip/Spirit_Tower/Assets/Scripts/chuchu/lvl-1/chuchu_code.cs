﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class chuchu_code : MonoBehaviour
{
    public static float posx;
    public static float posy;
    public static bool vivo;
    public GameObject flecha;
    GameObject player;

    public float numArrows;
    Vector3 PosicionInicial;
    public float LineaVision;
    public float velocidad;
    public static bool radiovision;
    public static double tamañoradio;
    public static double Velocidad;
    public static Vector3 target;
    public Vector3 posChuchu;


    public GameObject prefab;
    // Start is called before the first frame update
    void Start()
    {
        posx = gameObject.transform.position.x;
        posy = gameObject.transform.position.y;
        posChuchu = new Vector3(posx, posy, 0);

        //flecha = GameObject.FindGameObjectWithTag("Flecha");
        player = GameObject.FindGameObjectWithTag("Player");
        //flecha.transform.position = gameObject.transform.position;
        PosicionInicial = transform.position;
    }

    // Update is called once per frame

    void Update()
    {
        tamañoradio = LineaVision;
        Attack();

        StartCoroutine("Ciclo1");
        StartCoroutine("Ciclo");
        StartCoroutine("Ciclo2");
        StartCoroutine("Ciclo3");

    }

    void movechuchu()
    {
        gameObject.GetComponent<Animator>().SetBool("RightView", true);
        gameObject.GetComponent<Animator>().SetBool("RightView", false);
        gameObject.GetComponent<Animator>().SetBool("UpView", true);
        gameObject.GetComponent<Animator>().SetBool("UpView", false);
        gameObject.GetComponent<Animator>().SetBool("LeftView", true);
        gameObject.GetComponent<Animator>().SetBool("LeftView", false);
        gameObject.GetComponent<Animator>().SetBool("DownView", true);
        gameObject.GetComponent<Animator>().SetBool("DownView", false);

    }

    IEnumerator Ciclo()
    {
        gameObject.GetComponent<Animator>().SetBool("RightView", true);
        yield return new WaitForSeconds(3);
        gameObject.GetComponent<Animator>().SetBool("RightView", false);

    }
    IEnumerator Ciclo1()
    {
        gameObject.GetComponent<Animator>().SetBool("UpView", true);
        yield return new WaitForSeconds(3);
        gameObject.GetComponent<Animator>().SetBool("UpView", false);
    }
    IEnumerator Ciclo2()
    {
        gameObject.GetComponent<Animator>().SetBool("LeftView", true);
        yield return new WaitForSeconds(3);
        gameObject.GetComponent<Animator>().SetBool("LeftView", false);

    }
    IEnumerator Ciclo3()
    {
        gameObject.GetComponent<Animator>().SetBool("DownView", true);
        yield return new WaitForSeconds(3);
        gameObject.GetComponent<Animator>().SetBool("DownView", false);
    }

    void RightView()
    {

        gameObject.GetComponent<Animator>().SetBool("DownView", false);
        gameObject.GetComponent<Animator>().SetBool("LeftView", false);
        gameObject.GetComponent<Animator>().SetBool("UpView", false);
        gameObject.GetComponent<Animator>().SetBool("RightView", true);
    }

    void UpView()
    {
        gameObject.GetComponent<Animator>().SetBool("RightView", false);
        gameObject.GetComponent<Animator>().SetBool("LeftView", false);
        gameObject.GetComponent<Animator>().SetBool("DownView", false);
        gameObject.GetComponent<Animator>().SetBool("UpView", true);
    }

    void LeftView()
    {
        gameObject.GetComponent<Animator>().SetBool("UpView", false);
        gameObject.GetComponent<Animator>().SetBool("RightView", false);
        gameObject.GetComponent<Animator>().SetBool("DownView", false);
        gameObject.GetComponent<Animator>().SetBool("LeftView", true);
    }

    void DownView()
    {
        gameObject.GetComponent<Animator>().SetBool("UpView", false);
        gameObject.GetComponent<Animator>().SetBool("RightView", false);
        gameObject.GetComponent<Animator>().SetBool("LeftView", false);
        gameObject.GetComponent<Animator>().SetBool("DownView", true);
    }

    private void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            if (Input.GetKey("a"))
            {
                gameObject.SetActive(false);
            }


        }
    }
    bool first = true;
    float posX;
    float posY;
    //Vector3 target = new Vector3();
    public void Attack()
    {
        float dist = Vector3.Distance(player.transform.position, transform.position);
        if (dist < 10)
        {
            radiovision = true;
            if (first == true)
            {
                float posX = player.transform.position.x;
                float posY = player.transform.position.y;
                first = false;
                gameObject.GetComponent<Animator>().SetBool("Attack", true);
                gameObject.GetComponent<Animator>().SetBool("Attack", false);
                GameObject bullet = (GameObject)Instantiate(prefab);

            }


        }
        else
        {
            Destroy(GameObject.Find("Flecha(Clone)"));
            gameObject.GetComponent<Animator>().SetBool("Attack", false);
            first = true;
            radiovision = false;
        }
    }
}

