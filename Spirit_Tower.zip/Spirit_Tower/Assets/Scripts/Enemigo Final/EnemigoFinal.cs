﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class EnemigoFinal : MonoBehaviour
{
    public static string ultimoestado;
    public static float posx;
    public static float posy;
    public static float newposx;
    public static float newposy;
    public static bool vivo;
    public static bool radiovision;
    public static double tamañoradio;
    public static double Velocidad;
    GameObject player;

    public bool first = true;
    public float posX;
    public float posY;
    public GameObject prefab;
    public Image healthBar;
    public float curHealth;

    void Start()
    {
        curHealth = 100f;
        healthBar.fillAmount = curHealth/100f;
        posx = gameObject.transform.position.x;
        posy = gameObject.transform.position.y;
        newposx = gameObject.transform.position.x;
        newposy = gameObject.transform.position.y;

        player = GameObject.FindGameObjectWithTag("Player");
        vivo = true;
    }

    // Update is called once per frame
    void Update()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        radiovision = false;
        posX = gameObject.transform.position.x;
        posY = gameObject.transform.position.y;
        newposx = gameObject.transform.position.x;
        newposy = gameObject.transform.position.y;
        inRadio();

    }

    public void movimiento()
    { }

    public void inRadio()
    {
        float dist = Vector3.Distance(player.transform.position, transform.position);


        if (dist < 5)
        {
            radiovision = true;
            if (first == true)
            {

                float posX = player.transform.position.x;
                float posY = player.transform.position.y;
                first = false;
                GameObject bullet = (GameObject)Instantiate(prefab);
            }
        }
        else
        {
            Destroy(GameObject.Find("BolasFuego(Clone)"));
            first = true;
            radiovision = false;
        }

    }

    private void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            if (Input.GetKey("a"))
            {
                
                if (curHealth == 20)
                {
                    healthBar.fillAmount = 0;
                    gameObject.SetActive(false);
                    vivo = false;
                    
                    
                    

                }
                else
                {
                    curHealth -= 20f;
                    healthBar.fillAmount = curHealth / 100f;
                    AnimtionPlayer.trans.Translate(0, -80f * Time.deltaTime, 0);
                    
                }
            }


        }
    }

    IEnumerator esperar()
    {
        
        yield return new WaitForSeconds(3);

    }

}
