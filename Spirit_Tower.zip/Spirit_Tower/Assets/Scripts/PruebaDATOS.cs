﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System.IO;
using System;


public class PruebaDATOS : MonoBehaviour
{

    string filePath;
    string jsonString;
    void Awake()
    {
        //Recibirdatos();
        
    }
    

    public static void enviardatos() {
        JsonData Datajson = new JsonData();
        List<Personaje> lista1 = new List<Personaje>();


        Personaje player = new Personaje();
        player.name = "Player";
        player.posx = AnimtionPlayer.posx;
        player.posy = AnimtionPlayer.posy;
        player.vivo = AnimtionPlayer.vivo;
        player.velocidad = AnimtionPlayer.Velocidad;

        lista1.Add(player);

        Personaje EspectroGrisuno = new Personaje();
        EspectroGrisuno.name = "EspectroGris1";
        EspectroGrisuno.posx = EspectroGris1.newposx;
        EspectroGrisuno.posy = EspectroGris1.newposy;
        EspectroGrisuno.vivo = EspectroGris1.vivo;
        EspectroGrisuno.radiovision = EspectroGris1.radiovision;
        EspectroGrisuno.tamanoradio = EspectroGris1.tamañoradio;
        EspectroGrisuno.velocidad = EspectroGris1.Velocidad;

        lista1.Add(EspectroGrisuno);

        Personaje EspectroGrisdos = new Personaje();
        EspectroGrisdos.name = "EspectroGris2";
        EspectroGrisdos.posx = EG2.newposx;
        EspectroGrisdos.posy = EG2.newposy;
        EspectroGrisdos.vivo = EG2.vivo;
        EspectroGrisdos.radiovision = EG2.radiovision;
        EspectroGrisdos.tamanoradio = EG2.tamañoradio;
        EspectroGrisdos.velocidad = EG2.Velocidad;

        lista1.Add(EspectroGrisdos);

        Personaje EspectroGristres = new Personaje();
        EspectroGristres.name = "EspectroGris3";
        EspectroGristres.posx = EG3.newposx;
        EspectroGristres.posy = EG3.newposy;
        EspectroGristres.vivo = EG3.vivo;
        EspectroGristres.radiovision = EG3.radiovision;
        EspectroGristres.tamanoradio = EG3.tamañoradio;
        EspectroGristres.velocidad = EG3.Velocidad;

        lista1.Add(EspectroGristres);

        Personaje OjoEspectraluno = new Personaje();
        OjoEspectraluno.name = "OjoEspectral 1";
        OjoEspectraluno.posx = Ojoespectral.posx;
        OjoEspectraluno.posy = Ojoespectral.posy;
        OjoEspectraluno.vivo = Ojoespectral.vivo;
        OjoEspectraluno.radiovision = Ojoespectral.radiovision;
        OjoEspectraluno.tamanoradio = Ojoespectral.tamañoradio;
        OjoEspectraluno.velocidad = Ojoespectral.Velocidad;

        lista1.Add(OjoEspectraluno);

        Personaje OjoEspectraldos = new Personaje();
        OjoEspectraldos.name = "OjoEspectral 2";
        OjoEspectraldos.posx = Ojoespectral2.posx;
        OjoEspectraldos.posy = Ojoespectral2.posy;
        OjoEspectraldos.vivo = Ojoespectral2.vivo;
        OjoEspectraldos.radiovision = Ojoespectral2.radiovision;
        OjoEspectraldos.tamanoradio = Ojoespectral2.tamañoradio;
        OjoEspectraldos.velocidad = Ojoespectral2.Velocidad;

        lista1.Add(OjoEspectraldos);

        Personaje OjoEspectraltres = new Personaje();
        OjoEspectraltres.name = "OjoEspectral 3";
        OjoEspectraltres.posx = Ojoespectral3.posx;
        OjoEspectraltres.posy = Ojoespectral3.posy;
        OjoEspectraltres.vivo = Ojoespectral3.vivo;
        OjoEspectraltres.radiovision = Ojoespectral3.radiovision;
        OjoEspectraltres.tamanoradio = Ojoespectral3.tamañoradio;
        OjoEspectraltres.velocidad = Ojoespectral3.Velocidad;

        lista1.Add(OjoEspectraltres);

        Personaje Rata0 = new Personaje();
        Rata0.name = "Rata0";
        Rata0.posx = rata0.posx;
        Rata0.posy = rata0.posy;
        Rata0.vivo = rata0.vivo;
        Rata0.velocidad = rata0.Velocidad;
        lista1.Add(Rata0);

        Personaje Rata1 = new Personaje();
        Rata1.name = "Rata1";
        Rata1.posx = rata1.posx;
        Rata1.posy = rata1.posy;
        Rata1.vivo = rata1.vivo;
        Rata1.velocidad = rata1.Velocidad;

        lista1.Add(Rata1);

        Personaje Chuchu = new Personaje();
        Chuchu.name = "Chuchu";
        Chuchu.posx = chuchu_code.posx;
        Chuchu.posy = chuchu_code.posy;
        Chuchu.vivo = chuchu_code.vivo;
        Chuchu.radiovision = chuchu_code.radiovision;
        Chuchu.tamanoradio = chuchu_code.tamañoradio;


        lista1.Add(Chuchu);

        //
        Personaje ER10 = new Personaje();
        ER10.name = "Espectro Rojo 1";
        ER10.posx = Espectro_rojo_code.newposx;
        ER10.posy = Espectro_rojo_code.newposy;
        ER10.vivo = Espectro_rojo_code.vivo;
        ER10.radiovision = Espectro_rojo_code.radiovision;
        ER10.tamanoradio = Espectro_rojo_code.tamañoradio;
        ER10.velocidad = Espectro_rojo_code.Velocidad;

        lista1.Add(ER10);

        Personaje ER20 = new Personaje();
        ER20.name = "Espectro Rojo 2";
        ER20.posx = ER1.newposx;
        ER20.posy = ER1.newposy;
        ER20.vivo = ER1.vivo;
        ER20.radiovision = ER1.radiovision;
        ER20.tamanoradio = ER1.tamañoradio;
        ER20.velocidad = ER1.Velocidad;

        lista1.Add(ER20);

        Personaje ER30 = new Personaje();
        ER30.name = "Espectro Rojo 3";
        ER30.posx = ER2.newposx;
        ER30.posy = ER2.newposy;
        ER30.vivo = ER2.vivo;
        ER30.radiovision = ER2.radiovision;
        ER30.tamanoradio = ER2.tamañoradio;
        ER30.velocidad = ER2.Velocidad;

        lista1.Add(ER30);

        Personaje EA00 = new Personaje();
        EA00.name = "Espectro Azul 1";
        EA00.posx = EA0.newposx;
        EA00.posy = EA0.newposy;
        EA00.vivo = EA0.vivo;
        EA00.radiovision = EA0.radiovision;
        EA00.tamanoradio = EA0.tamañoradio;
        EA00.velocidad = EA0.Velocidad;

        lista1.Add(EA00);

        Personaje EA10 = new Personaje();
        EA10.name = "Espectro Azul 2";
        EA10.posx = EA1.newposx;
        EA10.posy = EA1.newposy;
        EA10.vivo = EA1.vivo;
        EA10.radiovision = EA1.radiovision;
        EA10.tamanoradio = EA1.tamañoradio;
        EA10.velocidad = EA1.Velocidad;

        lista1.Add(EA10);

        Personaje EA30 = new Personaje();
        EA30.name = "Espectro Azul 3";
        EA30.posx = EA2.newposx;
        EA30.posy = EA2.newposy;
        EA30.vivo = EA2.vivo;
        EA30.radiovision = EA2.radiovision;
        EA30.tamanoradio = EA2.tamañoradio;
        EA30.velocidad = EA2.Velocidad;

        lista1.Add(EA30);

        Personaje enemigofinal = new Personaje();
        enemigofinal.name = "Enemigo Final ";
        enemigofinal.posx = EnemigoFinal.posx;
        enemigofinal.posy = EnemigoFinal.posy;
        enemigofinal.vivo = EnemigoFinal.vivo;
        enemigofinal.radiovision = EnemigoFinal.radiovision;
        enemigofinal.tamanoradio = EnemigoFinal.tamañoradio;
        enemigofinal.velocidad = EnemigoFinal.Velocidad;
        lista1.Add(enemigofinal);



        Juego Datos = new Juego();
        Datos.level = DATOS_JUEGO.level;
        Datos.puntos = DATOS_JUEGO.puntos;
        Datos.cofres= DATOS_JUEGO.cofres;
        Datos.vidas = DATOS_JUEGO.vidas;
        Datos.personaje_zona_segura = AnimtionPlayer.personaje_zona_segura;
        print(JsonMapper.ToJson(lista1));
        lista1.Add(Datos);

        Datajson = JsonMapper.ToJson(lista1);

        File.WriteAllText("Assets/Misdatos.json",Datajson.ToString());
        print(JsonMapper.ToJson(lista1));
        



    }

    public static void Recibirdatos(string datos) {

        Personaje Misdatos = new Personaje();
        //JsonData MiJson = JsonMapper.ToObject(File.ReadAllText("Assets/Misdatos.json"));
        JsonData MiJson = JsonMapper.ToObject(datos);
        //Player

        try
        {
            AnimtionPlayer.posx = float.Parse(MiJson[0]["posx"].ToString());
        }
        catch (InvalidOperationException e)
        {
            int s = 0;
        }

        AnimtionPlayer.posy = float.Parse(MiJson[0]["posy"].ToString());
        AnimtionPlayer.Velocidad = float.Parse(MiJson[0]["velocidad"].ToString());

        //EspectroGris1
        EspectroGris1.posx = float.Parse(MiJson[1]["posx"].ToString());
        EspectroGris1.posy = float.Parse(MiJson[1]["posy"].ToString());
        EspectroGris1.Velocidad = float.Parse(MiJson[1]["velocidad"].ToString());
        EspectroGris1.tamañoradio = float.Parse(MiJson[1]["tamanoradio"].ToString());

        //EspectroGris2
        EG2.posx = float.Parse(MiJson[2]["posx"].ToString());
        EG2.posy = float.Parse(MiJson[2]["posy"].ToString());
        EG2.Velocidad = float.Parse(MiJson[2]["velocidad"].ToString());
        EG2.tamañoradio = float.Parse(MiJson[2]["tamanoradio"].ToString());

        //EspectroGris3
        EG3.posx = float.Parse(MiJson[3]["posx"].ToString());
        EG3.posy = float.Parse(MiJson[3]["posy"].ToString());
        EG3.Velocidad = float.Parse(MiJson[3]["velocidad"].ToString());
        EG3.tamañoradio = float.Parse(MiJson[3]["tamanoradio"].ToString());

        //OjoEspectral 1
        Ojoespectral.posx = float.Parse(MiJson[4]["posx"].ToString());
        Ojoespectral.posy = float.Parse(MiJson[4]["posy"].ToString());
        Ojoespectral.Velocidad = float.Parse(MiJson[4]["velocidad"].ToString());
        Ojoespectral.tamañoradio = float.Parse(MiJson[4]["tamanoradio"].ToString());


        ////OjoEspectral 2
        Ojoespectral2.posx = float.Parse(MiJson[5]["posx"].ToString());
        Ojoespectral2.posy = float.Parse(MiJson[5]["posy"].ToString());
        Ojoespectral2.Velocidad = float.Parse(MiJson[5]["velocidad"].ToString());
        Ojoespectral2.tamañoradio = float.Parse(MiJson[5]["tamanoradio"].ToString());

        ////OjoEspectral 3
        Ojoespectral3.posx = float.Parse(MiJson[6]["posx"].ToString());
        Ojoespectral3.posy = float.Parse(MiJson[6]["posy"].ToString());
        Ojoespectral3.Velocidad = float.Parse(MiJson[6]["velocidad"].ToString());
        Ojoespectral3.tamañoradio = float.Parse(MiJson[6]["tamanoradio"].ToString());

        //Rata0
        rata0.posx = float.Parse(MiJson[7]["posx"].ToString());
        rata0.posy = float.Parse(MiJson[7]["posy"].ToString());
        rata0.Velocidad = float.Parse(MiJson[7]["velocidad"].ToString());
        rata0.tamañoradio = float.Parse(MiJson[7]["tamanoradio"].ToString());

        //Rata1
        rata1.posx = float.Parse(MiJson[8]["posx"].ToString());
        rata1.posy = float.Parse(MiJson[8]["posy"].ToString());
        rata1.Velocidad = float.Parse(MiJson[8]["velocidad"].ToString());
        rata1.tamañoradio = float.Parse(MiJson[8]["tamanoradio"].ToString());

        //Chuchu
        chuchu_code.posx = float.Parse(MiJson[9]["posx"].ToString());
        chuchu_code.posy = float.Parse(MiJson[9]["posy"].ToString());
        chuchu_code.Velocidad = float.Parse(MiJson[9]["velocidad"].ToString());
        chuchu_code.tamañoradio = float.Parse(MiJson[9]["tamanoradio"].ToString());

        //Espectro Rojo 1
        Espectro_rojo_code.posx = float.Parse(MiJson[10]["posx"].ToString());
        Espectro_rojo_code.posy = float.Parse(MiJson[10]["posy"].ToString());
        Espectro_rojo_code.Velocidad = float.Parse(MiJson[10]["velocidad"].ToString());
        Espectro_rojo_code.tamañoradio = float.Parse(MiJson[10]["tamanoradio"].ToString());

        //Espectro Rojo 2
        ER1.posx = float.Parse(MiJson[11]["posx"].ToString());
        ER1.posy = float.Parse(MiJson[11]["posy"].ToString());
        ER1.Velocidad = float.Parse(MiJson[11]["velocidad"].ToString());
        ER1.tamañoradio = float.Parse(MiJson[11]["tamanoradio"].ToString());

        //Espectro Rojo 3
        ER2.posx = float.Parse(MiJson[12]["posx"].ToString());
        ER2.posy = float.Parse(MiJson[12]["posy"].ToString());
        ER2.Velocidad = float.Parse(MiJson[12]["velocidad"].ToString());
        ER2.tamañoradio = float.Parse(MiJson[12]["tamanoradio"].ToString());

        //Espectro Azul 1
        EA0.posx = float.Parse(MiJson[13]["posx"].ToString());
        EA0.posy = float.Parse(MiJson[13]["posy"].ToString());
        EA0.Velocidad = float.Parse(MiJson[13]["velocidad"].ToString());
        EA0.tamañoradio = float.Parse(MiJson[13]["tamanoradio"].ToString());

        //Espectro Azul 2
        EA1.posx = float.Parse(MiJson[14]["posx"].ToString());
        EA1.posy = float.Parse(MiJson[14]["posy"].ToString());
        EA1.Velocidad = float.Parse(MiJson[14]["velocidad"].ToString());
        EA1.tamañoradio = float.Parse(MiJson[14]["tamanoradio"].ToString());

        //Espectro Azul 3
        EA2.posx = float.Parse(MiJson[15]["posx"].ToString());
        EA2.posy = float.Parse(MiJson[15]["posy"].ToString());
        EA2.Velocidad = float.Parse(MiJson[15]["velocidad"].ToString());
        EA2.tamañoradio = float.Parse(MiJson[15]["tamanoradio"].ToString());

        //Enemigo Final
        EnemigoFinal.posx = float.Parse(MiJson[16]["posx"].ToString());
        EnemigoFinal.posy = float.Parse(MiJson[16]["posy"].ToString());
        EnemigoFinal.Velocidad = float.Parse(MiJson[16]["velocidad"].ToString());
        EnemigoFinal.tamañoradio = float.Parse(MiJson[16]["tamanoradio"].ToString());

        //Datos juego
        DATOS_JUEGO.vidas = int.Parse(MiJson[17]["vidas"].ToString());
        DATOS_JUEGO.puntos = int.Parse(MiJson[17]["puntos"].ToString());
        DATOS_JUEGO.cofres = int.Parse(MiJson[17]["cofres"].ToString());

        //print(x1.ToString() + " ," + y1.ToString() +", "+ z1.ToString());

    }

}

[System.Serializable]
public class Personaje
{
    public string name;
    public double posx;
    public double posy;
    public bool vivo;
    public double velocidad;
    public bool radiovision;
    public double tamanoradio;
    

    public override string ToString()
    {
        return string.Format( "{0}: pox {1} poy {2}",name, posx , posy);

    }
}

[System.Serializable]
public class ListaPersonajes
{
    public List<Personaje> personajes;

    public void Listar()
    {
        foreach (Personaje personaje in personajes)
        {
            Debug.Log(personaje);

        }

    }

}
[System.Serializable]
public class Juego : Personaje 
{ 
    public int vidas;
    public int puntos;
    public int cofres;
    public string level;
    public bool personaje_zona_segura;

    public override string ToString()
    {
        return string.Format("{0}: puntos {1} cofres {2}  {3}", level, puntos, cofres, vidas);

    }
}