﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EA2 : MonoBehaviour
{
    public static string ultimoestado;
    public static float posx;
    public static float posy;
    public static float newposx;
    public static float newposy;
    public static bool vivo;
    public static bool radiovision;
    public static double tamañoradio;
    public static double Velocidad;
    GameObject player;
    public float posX;
    public float posY;
    // Start is called before the first frame update
    void Start()
    {
        posx = gameObject.transform.position.x;
        posy = gameObject.transform.position.y;
        newposx = gameObject.transform.position.x;
        newposy = gameObject.transform.position.y;

        player = GameObject.FindGameObjectWithTag("Player");
        vivo = true;
    }

    // Update is called once per frame
    void Update()
    {

        radiovision = false;
        posX = gameObject.transform.position.x;
        posY = gameObject.transform.position.y;
        newposx = gameObject.transform.position.x;
        newposy = gameObject.transform.position.y;
        movimiento();
        inRadio();
    }

    public void movimiento()
    {
        Vector3 primerPunto = new Vector3(posx, posy, 0);

        if (posx < posX)
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", true);
            ultimoestado = "izquierda";
        }
        else if (posx > posX)
        {
            gameObject.GetComponent<Animator>().SetBool("RightMove", true);
            ultimoestado = "derecha";
        }
        else if (posx == posX)
        {

            if (posy > posY)
            {
                gameObject.GetComponent<Animator>().SetBool("UpMove", true);
                ultimoestado = "arriba";
            }
            else if (posy < posY)
            {
                gameObject.GetComponent<Animator>().SetBool("DownMove", true);
                ultimoestado = "abajo";
            }
        }
        else
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", false);
            gameObject.GetComponent<Animator>().SetBool("RightMove", false);
            gameObject.GetComponent<Animator>().SetBool("UpMove", false);
            gameObject.GetComponent<Animator>().SetBool("DownMove", false);

        }
        transform.position = Vector3.MoveTowards(new Vector3(posX, posY, 0), primerPunto, (float)Velocidad * Time.deltaTime);
        posx = posX;
        posy = posY;
    }

    public void inRadio()
    {
        float dist = Vector3.Distance(player.transform.position, transform.position);

        if (dist < tamañoradio)
        {
            if (ultimoestado == "derecha")
            {
                if (AnimtionPlayer.posx < posX)
                {
                    radiovision = false;
                }
                else
                {
                    radiovision = true;
                }

            }
            if (ultimoestado == "izquierda")
            {
                if (player.transform.position.x > posX)
                {
                    radiovision = false;
                }
                else
                {
                    radiovision = true;
                }

            }
            if (ultimoestado == "abajo")
            {
                if (player.transform.position.y > posY)
                {
                    radiovision = false;
                }
                else
                {
                    radiovision = true;
                }


            }
            if (ultimoestado == "arriba")
            {
                if (player.transform.position.y < posY)
                {
                    radiovision = false;
                }
                else
                {
                    radiovision = true;
                }

            }
        }
        else
        {
            radiovision = false;
        }

    }
    
}
