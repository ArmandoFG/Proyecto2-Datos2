﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class cambio1 : MonoBehaviour
{
    

    // Update is called once per frame
    void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player")) {
            SceneManager.LoadScene("Level 2");
            DATOS_JUEGO.level = "Level 2";
        }
    }
}
