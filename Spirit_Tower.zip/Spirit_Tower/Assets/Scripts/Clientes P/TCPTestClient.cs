﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;


public class TCPTestClient : MonoBehaviour
{

	#region public members
	public string path = "Assets/Misdatos.json";
	static public IPHostEntry ipHostInfo;
	static public IPAddress ipAddress;
	static public IPEndPoint remoteEP;
	static public Socket sender;
	#endregion

	
	#region private members 	
	private TcpClient socketConnection;
	private Thread clientReceiveThread;
	#endregion
	// Use this for initialization 	
	void Start()
	{
		ConnectToTcpServer();
		
	}
	// Update is called once per frame
	void Update()
	{
		DontDestroyOnLoad(gameObject);
		if (Input.GetKeyDown(KeyCode.I))
		{
			SendMessage();
		}
	}
	/// <summary> 	
	/// Setup socket connection. 	
	/// </summary> 	
	private void ConnectToTcpServer()
	{
		try
		{
			ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
			ipAddress = ipHostInfo.AddressList[0];
			remoteEP = new IPEndPoint(ipAddress, 12345);
			// Create a TCP/IP  socket.  
			sender = new Socket(ipAddress.AddressFamily,
			SocketType.Stream, 0);
			clientReceiveThread = new Thread(new ThreadStart(ListenForData));
			clientReceiveThread.IsBackground = true;
			clientReceiveThread.Start();
			Console.WriteLine("hsada");

		}
		catch (Exception e)
		{
			Console.WriteLine("On client connect exception " + e);
		}
	}
	/// <summary> 	
	/// Runs in background clientReceiveThread; Listens for incomming data. 	
	/// </summary>     
	private void ListenForData()
	{
		
		try
		{
			sender.Connect(remoteEP);


			Console.WriteLine("Socket connected to {0}",
					sender.RemoteEndPoint.ToString());

			//socketConnection = new TcpClient("127.0.0.1", 12345);
			Byte[] bytes = new Byte[1024];
			while (true)
			{
				// Get a stream object for reading 		

			}
		}
		
		catch (SocketException socketException)
		{
			Debug.Log("Socket exception: " + socketException);
		}
	}
	/// <summary> 	
	/// Send message to server using socket connection. 	
	/// </summary> 	
	private void SendMessage()
	{
		if (socketConnection == null)
		{
			return;
		}
		try
		{
			// Get a stream object for writing. 			
			NetworkStream stream = socketConnection.GetStream();
			if (stream.CanWrite)
			{

				string clientMessage = "path";
				// Convert string message to byte array.                 
				byte[] clientMessageAsByteArray = Encoding.ASCII.GetBytes(clientMessage);
				// Write byte array to socketConnection stream.                 
				stream.Write(clientMessageAsByteArray, 0, clientMessageAsByteArray.Length);
				Debug.Log("Client sent his message - should be received by server");
			}
		}
		catch (SocketException socketException)
		{
			Debug.Log("Socket exception: " + socketException);
		}
	}
}
