﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DATOS_JUEGO : MonoBehaviour
{



    public static float maxHealth = 100f;
    public static float curHealth = 100f;
    public static int puntos = 0;
    public static int cofres = 0;
    public static string level = "Level 1";
    public static int vidas = (int)curHealth / 20;


    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}

