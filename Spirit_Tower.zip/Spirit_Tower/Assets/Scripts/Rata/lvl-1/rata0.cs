﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rata0 : MonoBehaviour
{
    public static float posx;
    public static float posy;
    public static bool vivo;
    public static float posX;
    public static float posY;
    public static string ultimoestado;
    public static bool radiovision;
    public static double tamañoradio;
    public static double Velocidad;
    GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        posx = gameObject.transform.position.x;
        posy = gameObject.transform.position.y;
        vivo = true;
        player = GameObject.FindGameObjectWithTag("EspectroGris");
    }

    // Update is called once per frame
    void Update()
    {

        player = GameObject.FindGameObjectWithTag("EspectroGris");
        radiovision = false;
        gameObject.GetComponent<Animator>().SetBool("LeftMove", false);
        gameObject.GetComponent<Animator>().SetBool("RightMove", false);
        gameObject.GetComponent<Animator>().SetBool("UpMove", false);
        gameObject.GetComponent<Animator>().SetBool("DownMove", false);

        posX = gameObject.transform.position.x;
        posY = gameObject.transform.position.y;

        movimiento();
        inRadio();

    }

    public void inRadio()
    {
        float dist = Vector3.Distance(player.transform.position, transform.position);

        if (dist < 3)
        {
            radiovision = true;

        }
    }

    public void movimiento()
    {
        Vector3 primerPunto = new Vector3(posx, posy, 0);

        if (posx < posX)
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", true);
            ultimoestado = "izquierda";
        }
        else if (posx > posX)
        {
            gameObject.GetComponent<Animator>().SetBool("RightMove", true);
            ultimoestado = "derecha";
        }
        else if (posx == posX)
        {

            if (posy > posY)
            {
                gameObject.GetComponent<Animator>().SetBool("UpMove", true);
                ultimoestado = "arriba";
            }
            else if (posy < posY)
            {
                gameObject.GetComponent<Animator>().SetBool("DownMove", true);
                ultimoestado = "abajo";
            }
        }
        else
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", false);
            gameObject.GetComponent<Animator>().SetBool("RightMove", false);
            gameObject.GetComponent<Animator>().SetBool("UpMove", false);
            gameObject.GetComponent<Animator>().SetBool("DownMove", false);

        }
        transform.position = Vector3.MoveTowards(new Vector3(posX, posY, 0), primerPunto, (float)Velocidad * Time.deltaTime);

    }

    private void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            if (Input.GetKey("a"))
            {
                gameObject.SetActive(false);
                vivo = false;
            }


        }
    }
}
