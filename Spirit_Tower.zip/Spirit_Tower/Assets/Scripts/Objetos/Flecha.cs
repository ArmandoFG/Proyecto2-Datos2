﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flecha : MonoBehaviour
{
    GameObject player;
    Vector3 target = new Vector3();

    // Start is called before the first frame update
    void Start()
    {
        gameObject.transform.position = new Vector3(chuchu_code.posx, chuchu_code.posy, 0);
        player = GameObject.FindGameObjectWithTag("Player");
        Vector3 nueva = new Vector3(chuchu_code.posx, chuchu_code.posy, 0);
        target = nueva;
    }

    // Update is called once per frame
    void Update()
    {


        float arregloVelocidad = 7f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, arregloVelocidad);
        movimiento();
    }

    public void movimiento()
    {


        if (gameObject.transform.position.x < player.transform.position.x)
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", true);
        }
        else if (gameObject.transform.position.x > player.transform.position.x)
        {
            gameObject.GetComponent<Animator>().SetBool("RightMove", true);

        }
        else if (gameObject.transform.position.x == player.transform.position.x)
        {

            if (gameObject.transform.position.y > player.transform.position.y)
            {
                gameObject.GetComponent<Animator>().SetBool("UpMove", true);
            }
            else if (gameObject.transform.position.y < player.transform.position.y)
            {
                gameObject.GetComponent<Animator>().SetBool("DownMove", true);

            }
        }
        else
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", false);
            gameObject.GetComponent<Animator>().SetBool("RightMove", false);
            gameObject.GetComponent<Animator>().SetBool("UpMove", false);
            gameObject.GetComponent<Animator>().SetBool("DownMove", false);

        }

    }
}
