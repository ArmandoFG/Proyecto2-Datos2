﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BolaFinal : MonoBehaviour
{
    // Start is called before the first frame update

    GameObject player;
    Vector3 target = new Vector3();

    // Start is called before the first frame update
    void Start()
    {
        gameObject.transform.position = new Vector3(EnemigoFinal.posx, EnemigoFinal.posy, 0);
        player = GameObject.FindGameObjectWithTag("Player");

        target = player.transform.position;
    }

    // Update is called once per frame
    void Update()
    {


        float arregloVelocidad = 7f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, arregloVelocidad);
       
    }
}
