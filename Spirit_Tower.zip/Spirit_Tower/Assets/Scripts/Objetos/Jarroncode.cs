﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jarroncode : MonoBehaviour
{
    // Start is called before the first frame update
    Animator Jarron;
    public GameObject corazon;
    public float delay;

    public int corazonestotal;
    int cuenta;
    int vecesdecorazon;

    void Start()
    {
        Jarron = GetComponent<Animator>();
    }

    // Update is called once per frame
    private void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player")) {
            if (Input.GetKey("a")) {
                
                if (vecesdecorazon == 0)
                {
                    Jarron.Play("jarron_open");
                    StartCoroutine(Getcorazon());
                    vecesdecorazon = 1;

                }
            }
            

        }
    }
    IEnumerator Getcorazon()
    {
        while (cuenta < corazonestotal) 
        { 
        yield return new WaitForSeconds(delay);
        Instantiate(corazon, transform.position, Quaternion.identity);

            cuenta++;
        }
    }
}
