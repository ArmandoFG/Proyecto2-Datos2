﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cofrecode : MonoBehaviour
{
    Animator cofre;
    public GameObject coins;
    public float  delay;

    public int coinstotal;
    int cuenta;
    int vecesdecoins;

    void Start()
    {
        cofre = GetComponent<Animator>();
    }

    // Update is called once per frame
    private void OnTriggerStay2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            if (Input.GetKey("a"))
            {

                if (vecesdecoins == 0)
                {
                    cofre.Play("OpenChest");
                    StartCoroutine(Getcoins());
                    vecesdecoins = 1;

                }
            }


        }
    }
    IEnumerator Getcoins()
    {
        while (cuenta < coinstotal)
        {
            yield return new WaitForSeconds(delay);
            Instantiate(coins, transform.position, Quaternion.identity);

            cuenta++;
        }
    }
}