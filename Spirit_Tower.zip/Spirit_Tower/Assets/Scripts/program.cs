﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using System.Threading.Tasks;
using System.Timers;
using UnityEngine;
//dotnet add package Newtonsoft.Json




	public class program : MonoBehaviour
	{
		#region public members
		static public IPHostEntry ipHostInfo;

		static public byte[] b;

		static public byte[] rb = new byte[4096];

		static public byte[] info;


		static public int len;

		//	static public int client;

		static public int lenR;
		static public IPAddress ipAddress;
		static public IPEndPoint remoteEP;

		static public Socket sender;
		#endregion

		#region private members 	
		static private Thread clientReceiveThread;
		
	#endregion
	// Use this for initialization 	
		void Start()
		{
		Debug.Log("funcionando ");
		DontDestroyOnLoad(gameObject);
		ConnectToTcpServer();
		
		

		}
		// Update is called once per frame
		
		
		
	/// <summary> 	
	/// Setup socket connection. 	
	/// </summary> 	
	static void ConnectToTcpServer()
		{
			try
			{
				ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
				ipAddress = ipHostInfo.AddressList[0];
				remoteEP = new IPEndPoint(ipAddress, 12345);
				sender = new Socket(ipAddress.AddressFamily,
				SocketType.Stream, 0);
				clientReceiveThread = new Thread(new ThreadStart(ListenForData));
				clientReceiveThread.IsBackground = true;
				clientReceiveThread.Start();
				Debug.Log("Conectado al server");

			}
			catch (Exception e)
			{
				Debug.Log("On client connect exception " + e);
			}
		}
		/// <summary> 	
		/// Runs in background clientReceiveThread; Listens for incomming data. 	
		/// </summary>     
		static private void ListenForData()
		{
		
		try
			{
				sender.Connect(remoteEP);


				Debug.Log("Socket connected to {0}"+
						sender.RemoteEndPoint.ToString());





				while (true)
				{
					PruebaDATOS.enviardatos();
					string clientMessage1 = File.ReadAllText("Assets/Misdatos.json");
					byte[] msg = Encoding.ASCII.GetBytes(clientMessage1);
					sender.Send(
					msg, 0, msg.Length, 0);
					Debug.Log("Esperando respuesta del server");

					int bytesRec = sender.Receive(rb);
					string clientMessage = Encoding.ASCII.GetString(rb, 0, bytesRec);
					PruebaDATOS.Recibirdatos(clientMessage);
					Debug.Log(clientMessage);
				}
			}
			catch (SocketException socketException)
			{
				Debug.Log("Socket exception: " + socketException);
			}
		}






		/// <summary> 	
		/// Send message to server using socket connection. 	
		/// </summary> 	

	}


