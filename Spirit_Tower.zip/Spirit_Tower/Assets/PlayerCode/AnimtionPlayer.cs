﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class AnimtionPlayer : MonoBehaviour
{
    //public float maxHealth = 100f;
    //float curHealth;
    public Image healthBar;
    public Text Text;
    //int puntos = 0;
    public Text cofres_obtenidos;
    public static string ultimoestado;
    public static float posx;
    public static float posy;
    public static bool vivo;
    public static bool personaje_zona_segura;
    public static double Velocidad;
    public static Transform trans;
    public int x = 0 ;
    //int cofres = 0;

    // Start is called before the first frame update
    void Start()
    {
        EnemigoFinal.vivo = true;

        trans = transform;
        posx = gameObject.transform.position.x;
        posy = gameObject.transform.position.y;
        healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
        Text.text = "=  " + DATOS_JUEGO.puntos;
        cofres_obtenidos.text = "=  " + DATOS_JUEGO.cofres;
        personaje_zona_segura = false;
    }

    // Update is called once per frame
    void Update()
    {
        movePlayer();
        attackPlayer();
        defensePlayer();
        actualizarPuntajeEnemigoFinal();
    }
    private void movePlayer()
    {
        if (Input.GetKey("right"))
        {
            gameObject.transform.Translate(3f * Time.deltaTime, 0, 0);
            gameObject.GetComponent<Animator>().SetBool("RightMove", true);
            ultimoestado = "derecha";
            posx = gameObject.transform.position.x;
            posy = gameObject.transform.position.y;

        }
        if (!Input.GetKey("right"))
        {
            gameObject.GetComponent<Animator>().SetBool("RightMove", false);
        }
        if (Input.GetKey("left"))
        {
            gameObject.transform.Translate(-3f * Time.deltaTime, 0, 0);
            gameObject.GetComponent<Animator>().SetBool("LeftMove", true);
            ultimoestado = "izquierda";
            posx = gameObject.transform.position.x;
            posy = gameObject.transform.position.y;
        }
        if (!Input.GetKey("left"))
        {
            gameObject.GetComponent<Animator>().SetBool("LeftMove", false);
        }
        if (Input.GetKey("up"))
        {
            gameObject.transform.Translate(0, 3f * Time.deltaTime, 0);
            gameObject.GetComponent<Animator>().SetBool("UpMove", true);
            ultimoestado = "arriba";
            posx = gameObject.transform.position.x;
            posy = gameObject.transform.position.y;
        }
        if (!Input.GetKey("up"))
        {
            gameObject.GetComponent<Animator>().SetBool("UpMove", false);
        }

        if (Input.GetKey("down"))
        {
            gameObject.transform.Translate(0, -3f * Time.deltaTime, 0);
            gameObject.GetComponent<Animator>().SetBool("DownMove", true);
            ultimoestado = "abajo";
            posx = gameObject.transform.position.x;
            posy = gameObject.transform.position.y;
        }
        if (!Input.GetKey("down"))
        {
            gameObject.GetComponent<Animator>().SetBool("DownMove", false);
        }

       
    }
    private void attackPlayer()
    {
        if (Input.GetKey("a"))
        {
            gameObject.GetComponent<Animator>().SetBool("Attack", true);
        }
        if (!Input.GetKey("a"))
        {
            gameObject.GetComponent<Animator>().SetBool("Attack", false);
        }
    }

    private void defensePlayer()
    {
        if (Input.GetKey("s"))
        {
            gameObject.GetComponent<Animator>().SetBool("Defense", true);
        }
        if (!Input.GetKey("s"))
        {
            gameObject.GetComponent<Animator>().SetBool("Defense", false);
        }
    }


    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("hurt")) {
            if (Input.GetKey("a"))
            {
                if (ultimoestado == EspectroGris1.ultimoestado)
                {
                    col.gameObject.SetActive(false);
                    DATOS_JUEGO.puntos = DATOS_JUEGO.puntos + 70;
                    Text.text = "=  " + DATOS_JUEGO.puntos;
                }
            }
            else if (Input.GetKey("s")) { 
                
            }
            else
            {
                if (DATOS_JUEGO.curHealth == 20)
                {
                    healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                    DATOS_JUEGO.puntos = 0;
                    Text.text = "=  " + DATOS_JUEGO.puntos;
                    DATOS_JUEGO.cofres = 0;
                    cofres_obtenidos.text = "=  " + DATOS_JUEGO.cofres;
                    SceneManager.LoadScene("Level 1");
                    DATOS_JUEGO.curHealth = 100f;
                }
                else
                {
                    DATOS_JUEGO.curHealth -= 20;
                    healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                }
            }

        }

        if (col.CompareTag("Vida")) {
            if (DATOS_JUEGO.curHealth == 100)
            {
                healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
            }
            else
            {
                DATOS_JUEGO.curHealth += 20;
                healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                col.gameObject.SetActive(false);
            }
        }

        if (col.CompareTag("coin")) {
            DATOS_JUEGO.puntos = DATOS_JUEGO.puntos + 70;
            Text.text =  "=  "+ DATOS_JUEGO.puntos;
            col.gameObject.SetActive(false);
            DATOS_JUEGO.cofres = DATOS_JUEGO.cofres + 1;
            cofres_obtenidos.text = "=  " + DATOS_JUEGO.cofres;
        }

        if (col.CompareTag("Flecha")){
            if (Input.GetKey("s"))
            {

            }
            else
            {
                if (DATOS_JUEGO.curHealth == 20)
                {
                    healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                    DATOS_JUEGO.puntos = 0;
                    Text.text = "=  " + DATOS_JUEGO.puntos;
                    DATOS_JUEGO.cofres = 0;
                    cofres_obtenidos.text = "=  " + DATOS_JUEGO.cofres;
                    SceneManager.LoadScene("Level 1");
                    DATOS_JUEGO.curHealth = 100f;
                }
                else
                {
                    DATOS_JUEGO.curHealth -= 20;
                    healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                }
                col.gameObject.SetActive(false);
            }
        }
        if (col.CompareTag("EspectroGris"))
        {
            if (Input.GetKey("a"))
            {
                if (ultimoestado == EspectroGris1.ultimoestado)
                {
                    col.gameObject.SetActive(false);
                    DATOS_JUEGO.puntos = DATOS_JUEGO.puntos + 70;
                    Text.text = "=  " + DATOS_JUEGO.puntos;
                }
            }
            else if (Input.GetKey("s"))
            {

            }
            else
            {
                if (DATOS_JUEGO.curHealth == 20)
                {
                    healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                    DATOS_JUEGO.puntos = 0;
                    Text.text = "=  " + DATOS_JUEGO.puntos;
                    DATOS_JUEGO.cofres = 0;
                    cofres_obtenidos.text = "=  " + DATOS_JUEGO.cofres;
                    SceneManager.LoadScene("Level 1");
                    DATOS_JUEGO.curHealth = 100f;
                }
                else
                {
                    DATOS_JUEGO.curHealth -= 20;
                    healthBar.fillAmount = DATOS_JUEGO.curHealth / DATOS_JUEGO.maxHealth;
                }
            }

        }
        if (col.CompareTag("Zona Seguro"))
        {
            personaje_zona_segura = true;
        }

        
    }

    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag("Zona Seguro"))
        {
            personaje_zona_segura = false;
        }
    }
    public  void actualizarPuntajeEnemigoFinal() {

        if (x == 0)
        {
            if (EnemigoFinal.vivo)
            {

            }
            else
            {
                DATOS_JUEGO.puntos = DATOS_JUEGO.puntos + 650;
                Text.text = "=  " + DATOS_JUEGO.puntos;
                x = 2;
            }
        }
    }
}
