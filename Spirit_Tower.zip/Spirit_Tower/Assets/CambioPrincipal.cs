﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CambioPrincipal : MonoBehaviour
{

    private void Start()
    {
        correr();
    }
    private void Update()
    {
        correr();
    }
    // Update is called once per frame
    public void correr(){
        if (Input.GetKey("c")) {
            Debug.Log("si");
            SceneManager.LoadScene("Level 1");
            DATOS_JUEGO.level = "Level 1";
        }
    }
}
