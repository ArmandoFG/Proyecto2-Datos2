var searchData=
[
  ['jugador_112',['Jugador',['../class_jugador.html',1,'']]]
];
