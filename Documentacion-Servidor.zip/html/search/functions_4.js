var searchData=
[
  ['espectro_144',['Espectro',['../class_espectro.html#ada224f63fcf9ef037b606dad739c3331',1,'Espectro']]],
  ['espectroazul_145',['EspectroAzul',['../class_espectro_azul.html#a95005c32674836d242c94ba125d9b516',1,'EspectroAzul']]],
  ['espectrogris_146',['EspectroGris',['../class_espectro_gris.html#acf47ef31f2fedaa4158e1b92f9be38f0',1,'EspectroGris']]],
  ['espectrorojo_147',['EspectroRojo',['../class_espectro_rojo.html#a601af8c3aa76566c50283a0f5736769e',1,'EspectroRojo']]]
];
