var searchData=
[
  ['ubicacion_221',['ubicacion',['../class_jugador.html#a248ce7a0a86ea2b52b9eaaf0092f7148',1,'Jugador']]]
];
