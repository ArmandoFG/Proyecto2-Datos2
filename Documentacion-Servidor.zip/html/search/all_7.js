var searchData=
[
  ['jugador_48',['Jugador',['../class_jugador.html',1,'']]]
];
