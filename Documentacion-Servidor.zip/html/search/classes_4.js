var searchData=
[
  ['genetico_111',['Genetico',['../class_genetico.html',1,'']]]
];
