var searchData=
[
  ['bresen_2',['bresen',['../classbresen.html',1,'bresen'],['../classbresen.html#adeb615ae7d5aae6ad750ec26099e6ce8',1,'bresen::bresen()']]]
];
