var searchData=
[
  ['iniciar_43',['Iniciar',['../classbresen.html#a48cf3e865f04ca938d30b2d15d1e7877',1,'bresen']]],
  ['iniciar_5fpoblacion_44',['Iniciar_Poblacion',['../class_genetico.html#ac1820a86d744fb6298e33804ea00b377',1,'Genetico']]],
  ['insertar_5fatributo_45',['insertar_atributo',['../class_genetico.html#ab84e715e6c6ec79fed6506b7c97439b3',1,'Genetico']]],
  ['insertar_5findividuo_46',['insertar_individuo',['../class_genetico.html#a24f16cab62010eb2b04914ea63bac3bf',1,'Genetico']]],
  ['isvivo_47',['isVivo',['../class_chuchu.html#a6ae10bca1f7ab4e3634ffb2659c6b3eb',1,'Chuchu::isVivo()'],['../class_espectro.html#a7936a828821f019ac2accae9df42c729',1,'Espectro::isVivo()'],['../class_ojo.html#a8ed04749580a8331a4926590e8dd5541',1,'Ojo::isVivo()'],['../class_raton.html#ac1e48715bd86555f0634899762e6ff59',1,'Raton::isVivo()']]]
];
