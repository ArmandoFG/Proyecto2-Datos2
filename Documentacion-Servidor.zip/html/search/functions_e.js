var searchData=
[
  ['write_222',['WRITE',['../class_operaciones___json.html#af183486640b8a40cd356aabee814da38',1,'Operaciones_Json']]]
];
