var searchData=
[
  ['checkearvision_3',['checkearVision',['../class_espectro.html#a6a3a76beb906bb025a1b4ebbf95cd587',1,'Espectro::checkearVision()'],['../class_ojo.html#aabe59093d6cb4eb0b2913b9e470f448c',1,'Ojo::checkearVision()'],['../class_raton.html#ad1a0cb9cd4a4a72d5ba558856f06020d',1,'Raton::checkearVision()']]],
  ['chuchu_4',['Chuchu',['../class_chuchu.html',1,'Chuchu'],['../class_chuchu.html#a8c004cead3f07a61a1e476c2f82f695d',1,'Chuchu::Chuchu()']]]
];
