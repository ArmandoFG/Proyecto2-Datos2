var searchData=
[
  ['mostrar_5fpoblacion_184',['mostrar_poblacion',['../class_genetico.html#a780e4035f2eb48aea170f3a9719d67d5',1,'Genetico']]],
  ['mover_185',['mover',['../class_espectro.html#a53b647b96212cc4755d5c171b784db0d',1,'Espectro']]],
  ['movimiento_186',['movimiento',['../class_chuchu.html#aa77db649cfb5198fe5f0a045e2f68548',1,'Chuchu::movimiento()'],['../class_ojo.html#a1d092f98b472bb862b7d473b3105bd75',1,'Ojo::movimiento()']]]
];
