var searchData=
[
  ['ojo_60',['Ojo',['../class_ojo.html',1,'Ojo'],['../class_ojo.html#ada8dbe14e22349caa02e518304f3dd75',1,'Ojo::Ojo()']]],
  ['operaciones_5fjson_61',['Operaciones_Json',['../class_operaciones___json.html',1,'']]]
];
