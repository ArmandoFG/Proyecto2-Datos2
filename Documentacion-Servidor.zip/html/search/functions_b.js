var searchData=
[
  ['seleccion_202',['seleccion',['../class_genetico.html#a3f1a0fe9a212a0bf1e6269bdbcf166fd',1,'Genetico']]],
  ['setmarcador_203',['setmarcador',['../class_jugador.html#ab346368fe79bfbfbb721eedb80c2f061',1,'Jugador']]],
  ['setojo_204',['setOjo',['../class_ojo.html#afc3cc3e6a7f61f926665925d4fd03fdd',1,'Ojo']]],
  ['setpersonajes_205',['setPersonajes',['../class_templo.html#ab1eed256891e651a4ba6481bd0fdecdf',1,'Templo']]],
  ['setpos_206',['setPos',['../class_chuchu.html#a206fe712d673b20bbc87668d3c9f2542',1,'Chuchu::setPos()'],['../class_ojo.html#a4f1cde19095b08e3f1471e8a50f4f891',1,'Ojo::setPos()'],['../class_raton.html#a90d9184ff32e4e46deaa9574db5b63e2',1,'Raton::setPos()']]],
  ['setraton_207',['setRaton',['../class_raton.html#ad7a6bbddd6811d7ef12b30044b911d18',1,'Raton']]],
  ['setvalue_208',['setValue',['../class_t_node.html#ace0fe11ac66692610c74185a14747088',1,'TNode']]],
  ['setvida_209',['setvida',['../class_jugador.html#ab044b2689d25b84a21fa7ae1a90e432f',1,'Jugador']]],
  ['setvistox_210',['setVistox',['../class_espectro.html#a5caeeedd4efedc976c21b91cc27ce414',1,'Espectro']]],
  ['setvistoy_211',['setVistoy',['../class_espectro.html#a889386c64383b00f67acd6d11edef274',1,'Espectro']]],
  ['setvivo_212',['setVivo',['../class_chuchu.html#a3e61860196818ca2f9434ba7a47c892c',1,'Chuchu::setVivo()'],['../class_espectro.html#ab5dc4125fd2861131e36b0c41ea372c9',1,'Espectro::setVivo()'],['../class_ojo.html#aa8a89acf646497ed10b22bf4c4de0088',1,'Ojo::setVivo()'],['../class_raton.html#aa83e5887e9834d0b7743d7fc4530c746',1,'Raton::setVivo()']]],
  ['setx_213',['setX',['../class_espectro.html#a8e5c3ae0e9f6f7afa9ce90752245f35a',1,'Espectro::setX()'],['../class_jugador.html#a333bf89e9d466b8958dcc170252fb964',1,'Jugador::setX()']]],
  ['sety_214',['setY',['../class_espectro.html#a7505f11ed4c4bd2933b33b700fd86a2a',1,'Espectro::setY()'],['../class_jugador.html#a392c9621452d31cf15121bdda6347f92',1,'Jugador::setY()']]],
  ['startciclo_215',['startCiclo',['../class_templo.html#a8ec3efdcd5883d433123146e47f54d28',1,'Templo']]]
];
